<?php
$pageTitle = 'Locações — ConectaFácil';
require_once __DIR__ . '/../includes/header.php';
$u = exigirLogin();
$db = getDB();

$filtro = $_GET['filtro'] ?? 'ativas';

if ($filtro === 'ativas') {
    $where = "WHERE l.status='ativa' AND l.data_prevista_devolucao >= CURDATE()";
} elseif ($filtro === 'atrasadas') {
    $where = "WHERE l.status='ativa' AND l.data_prevista_devolucao < CURDATE()";
} elseif ($filtro === 'finalizadas') {
    $where = "WHERE l.status='finalizada'";
} else {
    $where = "";
}

$locacoes = $db->query("
    SELECT l.*, c.nome AS cliente_nome, c.telefone AS cliente_tel,
           d.modelo, d.marca, d.valor_diaria, u.nome AS operador_nome
    FROM locacoes l
    JOIN clientes c ON l.cliente_id=c.id
    JOIN dispositivos d ON l.dispositivo_id=d.id
    JOIN usuarios u ON l.usuario_id=u.id
    $where
    ORDER BY l.criado_em DESC
")->fetchAll();

$hoje = new DateTime();
foreach ($locacoes as &$loc) {
    $prev = new DateTime($loc['data_prevista_devolucao']);
    $loc['atrasada'] = ($loc['status']==='ativa' && $prev < $hoje);
    $loc['dias_atraso'] = $loc['atrasada'] ? (int)$hoje->diff($prev)->days : 0;
}
unset($loc);

// Contagens para tabs
$cAtivas    = $db->query("SELECT COUNT(*) FROM locacoes WHERE status='ativa' AND data_prevista_devolucao >= CURDATE()")->fetchColumn();
$cAtrasadas = $db->query("SELECT COUNT(*) FROM locacoes WHERE status='ativa' AND data_prevista_devolucao < CURDATE()")->fetchColumn();
$cFinalizadas = $db->query("SELECT COUNT(*) FROM locacoes WHERE status='finalizada'")->fetchColumn();
$cTodas = $db->query("SELECT COUNT(*) FROM locacoes")->fetchColumn();
?>

<div class="d-flex align-items-center justify-content-between page-header">
    <div>
        <h4 class="fw-bold mb-1">📋 Locações</h4>
        <p class="text-muted mb-0" style="font-size:.875rem">Controle de todas as locações</p>
    </div>
    <a href="/conectafacil/locacoes/nova.php" class="btn btn-primary">➕ Nova Locação</a>
</div>

<!-- Tabs -->
<ul class="nav nav-tabs mb-3">
    <li class="nav-item"><a class="nav-link <?= $filtro==='ativas'?'active':'' ?>" href="?filtro=ativas">✅ Ativas (<?= $cAtivas ?>)</a></li>
    <li class="nav-item"><a class="nav-link text-danger <?= $filtro==='atrasadas'?'active':'' ?>" href="?filtro=atrasadas">⚠️ Atrasadas (<?= $cAtrasadas ?>)</a></li>
    <li class="nav-item"><a class="nav-link <?= $filtro==='finalizadas'?'active':'' ?>" href="?filtro=finalizadas">🏁 Finalizadas (<?= $cFinalizadas ?>)</a></li>
    <li class="nav-item"><a class="nav-link <?= $filtro==='todas'?'active':'' ?>" href="?filtro=todas">📄 Todas (<?= $cTodas ?>)</a></li>
</ul>

<div class="card">
    <div class="table-responsive">
        <table class="table table-hover mb-0">
            <thead><tr><th>#</th><th>Cliente</th><th>Dispositivo</th><th>Retirada</th><th>Dev. Prevista</th><th>Valor</th><th>Status</th><th>Ações</th></tr></thead>
            <tbody>
            <?php if (empty($locacoes)): ?>
                <tr><td colspan="8" class="text-center text-muted py-4">Nenhuma locação neste filtro.<br><a href="/conectafacil/locacoes/nova.php" class="btn btn-sm btn-primary mt-2">Registrar nova</a></td></tr>
            <?php else: ?>
            <?php foreach ($locacoes as $l): ?>
                <tr class="<?= $l['atrasada']?'table-warning':'' ?>">
                    <td><?= $l['id'] ?></td>
                    <td>
                        <strong><?= h($l['cliente_nome']) ?></strong>
                        <?php if ($l['cliente_tel']): ?><br><small class="text-muted">📞 <?= h($l['cliente_tel']) ?></small><?php endif; ?>
                    </td>
                    <td>
                        <strong><?= h($l['marca'].' '.$l['modelo']) ?></strong>
                        <br><small class="text-muted"><?= fmt($l['valor_diaria']) ?>/dia</small>
                    </td>
                    <td><?= fmtData($l['data_retirada']) ?></td>
                    <td>
                        <?= fmtData($l['data_prevista_devolucao']) ?>
                        <?php if ($l['atrasada']): ?>
                            <br><small class="text-danger fw-bold">⚠️ <?= $l['dias_atraso'] ?> dia(s) de atraso</small>
                        <?php endif; ?>
                    </td>
                    <td><?= fmt($l['valor_final'] ?? $l['valor_total'] ?? 0) ?></td>
                    <td>
                        <?php if ($l['atrasada']): ?>
                            <span class="badge badge-atrasada">Atrasada</span>
                        <?php else: ?>
                            <span class="badge badge-<?= $l['status'] ?>"><?= $l['status']==='ativa'?'Ativa':'Finalizada' ?></span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <a href="/conectafacil/locacoes/detalhe.php?id=<?= $l['id'] ?>" class="btn btn-sm btn-outline-secondary" title="Detalhes">👁️</a>
                        <?php if ($l['status']==='ativa'): ?>
                            <a href="/conectafacil/locacoes/devolucao.php?id=<?= $l['id'] ?>" class="btn btn-sm btn-success" title="Devolução">↩️</a>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
