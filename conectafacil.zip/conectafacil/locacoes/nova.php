<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/db.php';
$u = exigirLogin();
$db = getDB();

$erro = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $cliente_id = (int)$_POST['cliente_id'];
    $disp_id    = (int)$_POST['dispositivo_id'];
    $dt_ret     = $_POST['data_retirada'] ?? '';
    $dt_dev     = $_POST['data_prevista_devolucao'] ?? '';
    $obs        = trim($_POST['observacoes'] ?? '') ?: null;

    if (!$cliente_id || !$disp_id || !$dt_ret || !$dt_dev) {
        $erro = 'Preencha todos os campos obrigatórios.';
    } elseif ($dt_dev <= $dt_ret) {
        $erro = 'A data de devolução deve ser posterior à data de retirada.';
    } else {
        $st = $db->prepare("SELECT * FROM dispositivos WHERE id=? AND status='disponivel'");
        $st->execute([$disp_id]);
        $disp = $st->fetch();
        if (!$disp) {
            $erro = 'Dispositivo não está mais disponível.';
        } else {
            $d1 = new DateTime($dt_ret);
            
            $d2 = new DateTime($dt_dev);
            $dias = (int)$d1->diff($d2)->days;
            $valorTotal = $dias * (float)$disp['valor_diaria'];

            try {
                $db->beginTransaction();
                $db->prepare("
                    INSERT INTO locacoes (cliente_id,dispositivo_id,usuario_id,data_retirada,data_prevista_devolucao,
                    dias_locados,valor_total,valor_final,status,observacoes)
                    VALUES (?,?,?,?,?,?,?,?,?,?)
                ")->execute([$cliente_id,$disp_id,$u['id'],$dt_ret,$dt_dev,$dias,$valorTotal,$valorTotal,'ativa',$obs]);
                $db->prepare("UPDATE dispositivos SET status='alugado' WHERE id=?")->execute([$disp_id]);
                $db->commit();
                setFlash('success','Locação registrada com sucesso!');
                header('Location: /conectafacil/locacoes/index.php');
                exit;
            } catch (Exception $e) {
                $db->rollBack();
                $erro = 'Erro ao registrar locação. Tente novamente.';
            }
        }
    }
}

$dispositivos = $db->query("SELECT * FROM dispositivos WHERE status='disponivel' ORDER BY marca,modelo")->fetchAll();
$clientes     = $db->query("SELECT * FROM clientes ORDER BY nome")->fetchAll();

$pageTitle = 'Nova Locação — ConectaFácil';
require_once __DIR__ . '/../includes/header.php';
?>

<div class="page-header">
    <h4 class="fw-bold mb-1">➕ Nova Locação</h4>
    <p class="mb-0"><a href="/conectafacil/locacoes/index.php" class="breadcrumb-link">← Voltar para Locações</a></p>
</div>

<div class="card" style="max-width:750px">
    <div class="card-body">
        <?php if ($erro): ?><div class="alert alert-danger">❌ <?= h($erro) ?></div><?php endif; ?>

        <form method="POST" id="frmLocacao">
            <h6 class="text-muted border-bottom pb-2 mb-3">👤 Dados do Cliente</h6>
            <div class="mb-3">
                <label class="form-label">Cliente <span class="text-danger">*</span></label>
                <?php if (empty($clientes)): ?>
                    <div class="alert alert-warning">Nenhum cliente cadastrado. <a href="/conectafacil/admin/clientes.php?acao=novo">Cadastrar agora</a></div>
                <?php else: ?>
                <select name="cliente_id" class="form-select" required>
                    <option value="">Selecione um cliente...</option>
                    <?php foreach ($clientes as $c): ?>
                        <option value="<?= $c['id'] ?>" <?= ($_POST['cliente_id']??'')==$c['id']?'selected':'' ?>>
                            <?= h($c['nome']) ?><?= $c['cpf']?' — CPF: '.h($c['cpf']):'' ?><?= $c['telefone']?' | '.h($c['telefone']):'' ?>
                        </option>
                    <?php endforeach; ?>
                </select>
                <div class="mt-1"><a href="/conectafacil/admin/clientes.php?acao=novo" target="_blank" style="font-size:.75rem;color:#2563eb">➕ Cadastrar novo cliente</a></div>
                <?php endif; ?>
            </div>

            <h6 class="text-muted border-bottom pb-2 mb-3 mt-4">📱 Dispositivo</h6>
            <div class="mb-3">
                <label class="form-label">Dispositivo Disponível <span class="text-danger">*</span></label>
                <?php if (empty($dispositivos)): ?>
                    <div class="alert alert-warning">Nenhum dispositivo disponível no momento.</div>
                <?php else: ?>
                <select name="dispositivo_id" class="form-select" required onchange="calcular()" id="selDisp">
                    <option value="">Selecione um dispositivo...</option>
                    <?php foreach ($dispositivos as $d): ?>
                        <option value="<?= $d['id'] ?>" data-valor="<?= $d['valor_diaria'] ?>" <?= ($_POST['dispositivo_id']??'')==$d['id']?'selected':'' ?>>
                            <?= h($d['marca'].' '.$d['modelo']) ?> — R$ <?= number_format($d['valor_diaria'],2,',','.') ?>/dia
                        </option>
                    <?php endforeach; ?>
                </select>
                <?php endif; ?>
            </div>

            <h6 class="text-muted border-bottom pb-2 mb-3 mt-4">📅 Período</h6>
            <div class="row g-3 mb-3">
                <div class="col-md-6">
                    <label class="form-label">Data de Retirada <span class="text-danger">*</span></label>
                    <input type="date" name="data_retirada" id="dtRet" class="form-control" required
                           value="<?= $_POST['data_retirada'] ?? date('Y-m-d') ?>"
                           min="<?= date('Y-m-d') ?>" onchange="calcular()">
                </div>
                <div class="col-md-6">
                    <label class="form-label">Data Prevista de Devolução <span class="text-danger">*</span></label>
                    <input type="date" name="data_prevista_devolucao" id="dtDev" class="form-control" required
                           value="<?= $_POST['data_prevista_devolucao'] ?? '' ?>" onchange="calcular()">
                </div>
            </div>

            <div id="preview" style="display:none" class="alert alert-info p-3 mb-3">
                <div class="d-flex justify-content-between mb-1"><span>Período:</span><strong id="pDias">—</strong></div>
                <div class="d-flex justify-content-between mb-1"><span>Valor da diária:</span><strong id="pDiaria">—</strong></div>
                <div class="d-flex justify-content-between fw-bold fs-6 border-top pt-2"><span>Valor Total Estimado:</span><strong class="text-success" id="pTotal">—</strong></div>
            </div>

            <h6 class="text-muted border-bottom pb-2 mb-3 mt-4">📝 Observações</h6>
            <textarea name="observacoes" class="form-control mb-4" rows="2" placeholder="Observações sobre a locação..."><?= h($_POST['observacoes'] ?? '') ?></textarea>

            <div class="d-flex gap-2 justify-content-end">
                <a href="/conectafacil/locacoes/index.php" class="btn btn-outline-secondary">Cancelar</a>
                <button type="submit" class="btn btn-primary">💾 Registrar Locação</button>
            </div>
        </form>
    </div>
</div>

<script>
function calcular() {
    const dtRet = document.getElementById('dtRet').value;
    const dtDev = document.getElementById('dtDev').value;
    const sel = document.getElementById('selDisp');
    const opt = sel ? sel.options[sel.selectedIndex] : null;
    const diaria = opt ? parseFloat(opt.dataset.valor || 0) : 0;

    if (dtRet && dtDev && diaria > 0) {
        const d1 = new Date(dtRet), d2 = new Date(dtDev);
        const dias = Math.round((d2 - d1) / 86400000);
        if (dias > 0) {
            document.getElementById('pDias').textContent = dias + ' dia(s)';
            document.getElementById('pDiaria').textContent = 'R$ ' + diaria.toFixed(2).replace('.', ',');
            document.getElementById('pTotal').textContent = 'R$ ' + (dias * diaria).toFixed(2).replace('.', ',');
            document.getElementById('preview').style.display = 'block';
            return;
        }
    }
    document.getElementById('preview').style.display = 'none';
}
document.addEventListener('DOMContentLoaded', calcular);
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
