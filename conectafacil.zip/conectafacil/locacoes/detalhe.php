<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/db.php';
$pageTitle = 'Detalhes da Locação — ConectaFácil';
$u = exigirLogin();
$db = getDB();

$id = (int)($_GET['id'] ?? 0);
if (!$id) { header('Location: /conectafacil/locacoes/index.php'); exit; }

$st = $db->prepare("
    SELECT l.*, c.nome AS cliente_nome, c.cpf, c.telefone, c.email AS cliente_email,
           d.modelo, d.marca, d.valor_diaria, d.imei, u.nome AS operador_nome
    FROM locacoes l
    JOIN clientes c ON l.cliente_id=c.id
    JOIN dispositivos d ON l.dispositivo_id=d.id
    JOIN usuarios u ON l.usuario_id=u.id
    WHERE l.id=?
");
$st->execute([$id]);
$loc = $st->fetch();

if (!$loc) {
    setFlash('error', 'Locação não encontrada.');
    header('Location: /conectafacil/locacoes/index.php'); exit;
}

$hoje = new DateTime();
$prev = new DateTime($loc['data_prevista_devolucao']);
$atrasada = ($loc['status']==='ativa' && $prev < $hoje);
$diasAtraso = $atrasada ? (int)$hoje->diff($prev)->days : 0;
require_once __DIR__ . '/../includes/header.php';
?>

<div class="d-flex align-items-center justify-content-between page-header">
    <div>
        <h4 class="fw-bold mb-1">📄 Locação #<?= $loc['id'] ?></h4>
        <p class="mb-0"><a href="/conectafacil/locacoes/index.php" class="breadcrumb-link">← Voltar para Locações</a></p>
    </div>
    <?php if ($loc['status']==='ativa'): ?>
        <a href="/conectafacil/locacoes/devolucao.php?id=<?= $loc['id'] ?>" class="btn btn-success">↩️ Registrar Devolução</a>
    <?php endif; ?>
</div>

<?php if ($atrasada): ?>
<div class="alert alert-danger">⚠️ Esta locação está com <strong><?= $diasAtraso ?> dia(s)</strong> de atraso!</div>
<?php endif; ?>

<div class="row g-3">
    <div class="col-md-6">
        <div class="card h-100">
            <div class="card-header"><strong>👤 Cliente</strong></div>
            <div class="card-body">
                <table class="table table-sm mb-0">
                    <tr><td class="text-muted w-50">Nome</td><td><strong><?= h($loc['cliente_nome']) ?></strong></td></tr>
                    <tr><td class="text-muted">CPF</td><td><?= h($loc['cpf'] ?? '—') ?></td></tr>
                    <tr><td class="text-muted">Telefone</td><td><?= h($loc['telefone'] ?? '—') ?></td></tr>
                    <tr><td class="text-muted">E-mail</td><td><?= h($loc['cliente_email'] ?? '—') ?></td></tr>
                </table>
            </div>
        </div>
    </div>

    <div class="col-md-6">
        <div class="card h-100">
            <div class="card-header"><strong>📱 Dispositivo</strong></div>
            <div class="card-body">
                <table class="table table-sm mb-0">
                    <tr><td class="text-muted w-50">Modelo</td><td><strong><?= h($loc['marca'].' '.$loc['modelo']) ?></strong></td></tr>
                    <tr><td class="text-muted">IMEI</td><td><?= h($loc['imei'] ?? '—') ?></td></tr>
                    <tr><td class="text-muted">Valor da Diária</td><td><?= fmt($loc['valor_diaria']) ?></td></tr>
                </table>
            </div>
        </div>
    </div>

    <div class="col-md-6">
        <div class="card h-100">
            <div class="card-header"><strong>📅 Período</strong></div>
            <div class="card-body">
                <table class="table table-sm mb-0">
                    <tr><td class="text-muted w-50">Retirada</td><td><strong><?= fmtData($loc['data_retirada']) ?></strong></td></tr>
                    <tr><td class="text-muted">Dev. Prevista</td><td><strong class="<?= $atrasada?'text-danger':'' ?>"><?= fmtData($loc['data_prevista_devolucao']) ?></strong></td></tr>
                    <?php if ($loc['data_devolucao']): ?>
                    <tr><td class="text-muted">Dev. Real</td><td><strong><?= fmtData($loc['data_devolucao']) ?></strong></td></tr>
                    <?php endif; ?>
                    <tr><td class="text-muted">Dias Locados</td><td><?= $loc['dias_locados'] ?> dia(s)</td></tr>
                    <?php if ($atrasada): ?>
                    <tr><td class="text-muted">Dias em Atraso</td><td><strong class="text-danger"><?= $diasAtraso ?> dia(s)</strong></td></tr>
                    <?php endif; ?>
                </table>
            </div>
        </div>
    </div>

    <div class="col-md-6">
        <div class="card h-100">
            <div class="card-header"><strong>💰 Valores</strong></div>
            <div class="card-body">
                <table class="table table-sm mb-0">
                    <tr><td class="text-muted w-50">Valor Locação</td><td><?= fmt($loc['valor_total']) ?></td></tr>
                    <?php if ((float)$loc['multa_atraso'] > 0): ?>
                    <tr><td class="text-muted">Multa Atraso</td><td class="text-danger"><strong><?= fmt($loc['multa_atraso']) ?></strong></td></tr>
                    <?php endif; ?>
                    <?php if ((float)$loc['taxa_dano'] > 0): ?>
                    <tr><td class="text-muted">Taxa por Dano</td><td class="text-danger"><strong><?= fmt($loc['taxa_dano']) ?></strong></td></tr>
                    <?php endif; ?>
                    <tr class="fw-bold fs-6"><td>Valor Final</td><td class="text-success"><?= fmt($loc['valor_final'] ?? $loc['valor_total']) ?></td></tr>
                </table>
            </div>
        </div>
    </div>

    <div class="col-12">
        <div class="card">
            <div class="card-header"><strong>ℹ️ Informações Adicionais</strong></div>
            <div class="card-body">
                <table class="table table-sm mb-0">
                    <tr>
                        <td class="text-muted w-25">Status</td>
                        <td>
                            <?php if ($atrasada): ?>
                                <span class="badge badge-atrasada">Atrasada</span>
                            <?php else: ?>
                                <span class="badge badge-<?= $loc['status'] ?>"><?= $loc['status']==='ativa'?'Ativa':'Finalizada' ?></span>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr><td class="text-muted">Houve Dano</td><td><strong class="<?= $loc['houve_dano']?'text-danger':'text-success' ?>"><?= $loc['houve_dano']?'Sim':'Não' ?></strong></td></tr>
                    <?php if ($loc['descricao_dano']): ?>
                    <tr><td class="text-muted">Desc. do Dano</td><td><?= h($loc['descricao_dano']) ?></td></tr>
                    <?php endif; ?>
                    <tr><td class="text-muted">Operador</td><td><?= h($loc['operador_nome']) ?></td></tr>
                    <?php if ($loc['observacoes']): ?>
                    <tr><td class="text-muted">Observações</td><td><?= h($loc['observacoes']) ?></td></tr>
                    <?php endif; ?>
                    <tr><td class="text-muted">Registrado em</td><td><?= fmtData($loc['criado_em']) ?></td></tr>
                </table>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
