<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/db.php';
$pageTitle = 'Registrar Devolução — ConectaFácil';
$u = exigirLogin();
$db = getDB();

$id = (int)($_GET['id'] ?? 0);
if (!$id) { header('Location: /conectafacil/locacoes/index.php'); exit; }

$st = $db->prepare("
    SELECT l.*, c.nome AS cliente_nome, d.modelo, d.marca, d.valor_diaria
    FROM locacoes l JOIN clientes c ON l.cliente_id=c.id JOIN dispositivos d ON l.dispositivo_id=d.id
    WHERE l.id=? AND l.status='ativa'
");
$st->execute([$id]);
$loc = $st->fetch();

if (!$loc) {
    setFlash('error', 'Locação não encontrada ou já finalizada.');
    header('Location: /conectafacil/locacoes/index.php'); exit;
}

$hoje = new DateTime();
$prevista = new DateTime($loc['data_prevista_devolucao']);
$diasAtraso  = ($hoje > $prevista) ? (int)$hoje->diff($prevista)->days : 0;
$multaBase   = $diasAtraso > 0 ? $diasAtraso * (float)$loc['valor_diaria'] * 0.5 : 0;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $dtDev      = $_POST['data_devolucao'] ?? '';
    $houveDano  = ($_POST['houve_dano'] ?? 'nao') === 'sim' ? 1 : 0;
    $descDano   = trim($_POST['descricao_dano'] ?? '') ?: null;
    $taxaDano   = $houveDano ? (float)str_replace(',','.',$_POST['taxa_dano'] ?? 0) : 0;

    if (!$dtDev) {
        $erro = 'Informe a data de devolução.';
    } else {
        $devData = new DateTime($dtDev);
        $prevData = new DateTime($loc['data_prevista_devolucao']);
        $atraso   = ($devData > $prevData) ? (int)$devData->diff($prevData)->days : 0;
        $multa    = $atraso > 0 ? $atraso * (float)$loc['valor_diaria'] * 0.5 : 0;
        $total    = (float)$loc['valor_total'] + $multa + $taxaDano;

        try {
            $db->beginTransaction();
            $db->prepare("
                UPDATE locacoes SET data_devolucao=?,status='finalizada',houve_dano=?,descricao_dano=?,
                multa_atraso=?,taxa_dano=?,valor_final=? WHERE id=?
            ")->execute([$dtDev,$houveDano,$descDano,$multa,$taxaDano,$total,$id]);
            $db->prepare("UPDATE dispositivos SET status='disponivel' WHERE id=?")->execute([$loc['dispositivo_id']]);
            $db->commit();
            setFlash('success','Devolução registrada com sucesso!');
            header('Location: /conectafacil/locacoes/detalhe.php?id='.$id); exit;
        } catch (Exception $e) {
            $db->rollBack();
            $erro = 'Erro ao registrar devolução.';
        }
    }
}
require_once __DIR__ . '/../includes/header.php';
?>

<div class="page-header">
    <h4 class="fw-bold mb-1">↩️ Registrar Devolução</h4>
    <p class="mb-0"><a href="/conectafacil/locacoes/index.php" class="breadcrumb-link">← Voltar para Locações</a></p>
</div>

<!-- Resumo da locação -->
<div class="card mb-3 border-primary" style="max-width:750px">
    <div class="card-header bg-primary text-white"><strong>📋 Locação #<?= $loc['id'] ?></strong></div>
    <div class="card-body">
        <div class="row g-2">
            <div class="col-6 col-md-4"><small class="text-muted d-block">Cliente</small><strong><?= h($loc['cliente_nome']) ?></strong></div>
            <div class="col-6 col-md-4"><small class="text-muted d-block">Dispositivo</small><strong><?= h($loc['marca'].' '.$loc['modelo']) ?></strong></div>
            <div class="col-6 col-md-4"><small class="text-muted d-block">Retirada</small><strong><?= fmtData($loc['data_retirada']) ?></strong></div>
            <div class="col-6 col-md-4"><small class="text-muted d-block">Dev. Prevista</small><strong class="<?= $diasAtraso>0?'text-danger':'' ?>"><?= fmtData($loc['data_prevista_devolucao']) ?></strong></div>
            <div class="col-6 col-md-4"><small class="text-muted d-block">Dias Locados</small><strong><?= $loc['dias_locados'] ?> dia(s)</strong></div>
            <div class="col-6 col-md-4"><small class="text-muted d-block">Valor Locação</small><strong><?= fmt($loc['valor_total']) ?></strong></div>
        </div>
        <?php if ($diasAtraso > 0): ?>
        <div class="alert alert-danger mt-3 mb-0 py-2">
            ⚠️ Esta locação está com <strong><?= $diasAtraso ?> dia(s)</strong> de atraso.
            Multa estimada: <strong><?= fmt($multaBase) ?></strong> (50% da diária por dia de atraso)
        </div>
        <?php endif; ?>
    </div>
</div>

<div class="card" style="max-width:750px">
    <div class="card-body">
        <?php if (!empty($erro)): ?><div class="alert alert-danger">❌ <?= h($erro) ?></div><?php endif; ?>
        <form method="POST" id="frmDev">
            <h6 class="text-muted border-bottom pb-2 mb-3">📅 Data de Devolução</h6>
            <div class="row g-3 mb-4">
                <div class="col-md-6">
                    <label class="form-label">Data de Devolução <span class="text-danger">*</span></label>
                    <input type="date" name="data_devolucao" id="dtDev" class="form-control" required
                           value="<?= date('Y-m-d') ?>" onchange="calcular()">
                </div>
            </div>

            <h6 class="text-muted border-bottom pb-2 mb-3">🔍 Condição do Aparelho</h6>
            <div class="mb-3">
                <label class="form-label">Houve dano ao aparelho?</label>
                <div class="d-flex gap-3">
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="houve_dano" id="nao" value="nao" checked onchange="toggleDano(false)">
                        <label class="form-check-label" for="nao">✅ Não, aparelho em bom estado</label>
                    </div>
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="houve_dano" id="sim" value="sim" onchange="toggleDano(true)">
                        <label class="form-check-label text-danger" for="sim">❌ Sim, houve dano</label>
                    </div>
                </div>
            </div>
            <div id="camposDano" style="display:none" class="mb-3">
                <div class="row g-3">
                    <div class="col-md-6">
                        <label class="form-label">Taxa por Dano (R$)</label>
                        <input type="number" name="taxa_dano" id="taxaDano" class="form-control" step="0.01" min="0" value="0" onchange="calcular()">
                    </div>
                    <div class="col-12">
                        <label class="form-label">Descrição do Dano</label>
                        <textarea name="descricao_dano" class="form-control" rows="2" placeholder="Descreva o dano encontrado..."></textarea>
                    </div>
                </div>
            </div>

            <!-- Resumo Financeiro -->
            <div class="alert alert-secondary p-3 mb-4" id="resumo">
                <div class="d-flex justify-content-between mb-1"><span>Valor da locação:</span><strong><?= fmt($loc['valor_total']) ?></strong></div>
                <div class="d-flex justify-content-between mb-1 text-danger" id="lMulta" style="display:<?= $diasAtraso>0?'flex':'none' ?>!important">
                    <span>Multa por atraso (<span id="spDias"><?= $diasAtraso ?></span> dia(s)):</span>
                    <strong id="spMulta"><?= fmt($multaBase) ?></strong>
                </div>
                <div class="d-flex justify-content-between mb-1 text-danger" id="lDano" style="display:none">
                    <span>Taxa por dano:</span><strong id="spDano">R$ 0,00</strong>
                </div>
                <div class="d-flex justify-content-between fw-bold fs-6 border-top pt-2">
                    <span>Valor Final:</span><strong class="text-success" id="spTotal"><?= fmt((float)$loc['valor_total'] + $multaBase) ?></strong>
                </div>
            </div>

            <div class="d-flex gap-2 justify-content-end">
                <a href="/conectafacil/locacoes/index.php" class="btn btn-outline-secondary">Cancelar</a>
                <button type="submit" class="btn btn-success">✅ Confirmar Devolução</button>
            </div>
        </form>
    </div>
</div>

<script>
const valLocacao  = <?= (float)$loc['valor_total'] ?>;
const valDiaria   = <?= (float)$loc['valor_diaria'] ?>;
const dtPrevista  = '<?= $loc['data_prevista_devolucao'] ?>';

function toggleDano(show) {
    document.getElementById('camposDano').style.display = show ? 'block' : 'none';
    if (!show) document.getElementById('taxaDano').value = 0;
    calcular();
}

function calcular() {
    const dtDev = document.getElementById('dtDev').value;
    let multa = 0, diasAtraso = 0;
    if (dtDev) {
        const d1 = new Date(dtPrevista), d2 = new Date(dtDev);
        diasAtraso = Math.max(0, Math.round((d2 - d1) / 86400000));
        multa = diasAtraso * valDiaria * 0.5;
    }
    const dano = parseFloat(document.getElementById('taxaDano').value || 0);
    const total = valLocacao + multa + dano;

    document.getElementById('spDias').textContent = diasAtraso;
    document.getElementById('spMulta').textContent = 'R$ ' + multa.toFixed(2).replace('.', ',');
    document.getElementById('lMulta').style.display = diasAtraso > 0 ? 'flex' : 'none';
    document.getElementById('spDano').textContent = 'R$ ' + dano.toFixed(2).replace('.', ',');
    document.getElementById('lDano').style.display = dano > 0 ? 'flex' : 'none';
    document.getElementById('spTotal').textContent = 'R$ ' + total.toFixed(2).replace('.', ',');
}
document.addEventListener('DOMContentLoaded', calcular);
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
