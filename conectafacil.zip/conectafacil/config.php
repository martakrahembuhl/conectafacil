<?php
// =====================================================
// ConectaFácil — Configuração do Banco de Dados
// Se usar XAMPP padrão, não precisa mudar nada!
// =====================================================

define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');          // XAMPP padrão: sem senha
define('DB_NAME', 'conectafacil');
define('APP_NAME', 'conectafacil');
define('BASE_URL', '');         // Deixe vazio se estiver na raiz do htdocs
