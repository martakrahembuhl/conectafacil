<?php
$pageTitle = 'Dashboard — ConectaFácil';
require_once __DIR__ . '/includes/header.php';
$u = exigirLogin();
$db = getDB();

$stats = [
    'total'       => $db->query("SELECT COUNT(*) FROM dispositivos")->fetchColumn(),
    'disponiveis' => $db->query("SELECT COUNT(*) FROM dispositivos WHERE status='disponivel'")->fetchColumn(),
    'alugados'    => $db->query("SELECT COUNT(*) FROM dispositivos WHERE status='alugado'")->fetchColumn(),
    'ativas'      => $db->query("SELECT COUNT(*) FROM locacoes WHERE status='ativa'")->fetchColumn(),
    'clientes'    => $db->query("SELECT COUNT(*) FROM clientes")->fetchColumn(),
    'atrasadas'   => $db->query("SELECT COUNT(*) FROM locacoes WHERE status='ativa' AND data_prevista_devolucao < CURDATE()")->fetchColumn(),
    'faturamento' => $db->query("SELECT COALESCE(SUM(valor_final),0) FROM locacoes WHERE status='finalizada' AND MONTH(data_devolucao)=MONTH(CURDATE()) AND YEAR(data_devolucao)=YEAR(CURDATE())")->fetchColumn(),
];

$recentes = $db->query("
    SELECT l.id, c.nome AS cliente_nome, d.modelo, d.marca, l.data_prevista_devolucao, l.status, l.valor_final
    FROM locacoes l JOIN clientes c ON l.cliente_id=c.id JOIN dispositivos d ON l.dispositivo_id=d.id
    ORDER BY l.criado_em DESC LIMIT 5
")->fetchAll();

$atrasados = $db->query("
    SELECT l.id, c.nome AS cliente_nome, d.modelo, d.marca, l.data_prevista_devolucao,
           DATEDIFF(CURDATE(), l.data_prevista_devolucao) AS dias_atraso
    FROM locacoes l JOIN clientes c ON l.cliente_id=c.id JOIN dispositivos d ON l.dispositivo_id=d.id
    WHERE l.status='ativa' AND l.data_prevista_devolucao < CURDATE()
    ORDER BY dias_atraso DESC
")->fetchAll();
?>

<div class="page-header">
    <h4 class="fw-bold mb-1">📊 Dashboard</h4>
    <p class="text-muted mb-0" style="font-size:.875rem"><?= date('l, d \d\e F \d\e Y', strtotime('today')) ?></p>
</div>

<!-- Stats -->
<div class="row g-3 mb-4">
    <div class="col-6 col-md-4 col-xl-2">
        <div class="card stat-card border-primary h-100">
            <div class="card-body p-3">
                <div style="font-size:1.5rem">📱</div>
                <div class="fs-4 fw-bold"><?= $stats['total'] ?></div>
                <div class="text-muted small">Total Dispositivos</div>
            </div>
        </div>
    </div>
    <div class="col-6 col-md-4 col-xl-2">
        <div class="card stat-card border-success h-100">
            <div class="card-body p-3">
                <div style="font-size:1.5rem">✅</div>
                <div class="fs-4 fw-bold text-success"><?= $stats['disponiveis'] ?></div>
                <div class="text-muted small">Disponíveis</div>
            </div>
        </div>
    </div>
    <div class="col-6 col-md-4 col-xl-2">
        <div class="card stat-card border-warning h-100">
            <div class="card-body p-3">
                <div style="font-size:1.5rem">🤝</div>
                <div class="fs-4 fw-bold text-warning"><?= $stats['alugados'] ?></div>
                <div class="text-muted small">Alugados</div>
            </div>
        </div>
    </div>
    <div class="col-6 col-md-4 col-xl-2">
        <div class="card stat-card border-danger h-100">
            <div class="card-body p-3">
                <div style="font-size:1.5rem">⚠️</div>
                <div class="fs-4 fw-bold text-danger"><?= $stats['atrasadas'] ?></div>
                <div class="text-muted small">Em Atraso</div>
            </div>
        </div>
    </div>
    <div class="col-6 col-md-4 col-xl-2">
        <div class="card stat-card border-info h-100">
            <div class="card-body p-3">
                <div style="font-size:1.5rem">👥</div>
                <div class="fs-4 fw-bold"><?= $stats['clientes'] ?></div>
                <div class="text-muted small">Clientes</div>
            </div>
        </div>
    </div>
    <div class="col-6 col-md-4 col-xl-2">
        <div class="card stat-card border-success h-100">
            <div class="card-body p-3">
                <div style="font-size:1.5rem">💰</div>
                <div class="fs-5 fw-bold text-success"><?= fmt($stats['faturamento']) ?></div>
                <div class="text-muted small">Faturamento Mês</div>
            </div>
        </div>
    </div>
</div>

<div class="row g-3 mb-4">
    <!-- Últimas locações -->
    <div class="col-lg-7">
        <div class="card h-100">
            <div class="card-header d-flex align-items-center justify-content-between">
                <strong>🕐 Últimas Locações</strong>
                <a href="/conectafacil/locacoes/index.php" class="btn btn-sm btn-outline-secondary">Ver todas</a>
            </div>
            <div class="card-body p-0">
                <?php if (empty($recentes)): ?>
                    <div class="text-center text-muted py-4">Nenhuma locação ainda.</div>
                <?php else: ?>
                <table class="table table-hover mb-0">
                    <thead><tr><th>Cliente</th><th>Dispositivo</th><th>Devolução</th><th>Status</th></tr></thead>
                    <tbody>
                    <?php foreach ($recentes as $l): ?>
                        <tr>
                            <td><?= h($l['cliente_nome']) ?></td>
                            <td><?= h($l['marca'].' '.$l['modelo']) ?></td>
                            <td><?= fmtData($l['data_prevista_devolucao']) ?></td>
                            <td><span class="badge badge-<?= h($l['status']) ?>"><?= $l['status']==='ativa'?'Ativa':'Finalizada' ?></span></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Atrasos -->
    <div class="col-lg-5">
        <div class="card h-100">
            <div class="card-header d-flex align-items-center justify-content-between">
                <strong>⚠️ Devoluções Atrasadas</strong>
                <a href="/conectafacil/locacoes/index.php?filtro=atrasadas" class="btn btn-sm btn-outline-danger">Ver todas</a>
            </div>
            <div class="card-body p-0">
                <?php if (empty($atrasados)): ?>
                    <div class="text-center text-muted py-4">✅ Nenhum atraso!</div>
                <?php else: ?>
                <table class="table mb-0">
                    <thead><tr><th>Cliente</th><th>Dispositivo</th><th>Atraso</th></tr></thead>
                    <tbody>
                    <?php foreach ($atrasados as $l): ?>
                        <tr class="row-warning">
                            <td><?= h($l['cliente_nome']) ?></td>
                            <td><?= h($l['marca'].' '.$l['modelo']) ?></td>
                            <td><span class="badge badge-atrasada"><?= $l['dias_atraso'] ?> dia(s)</span></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<!-- Ações Rápidas -->
<div class="card">
    <div class="card-body">
        <strong class="d-block mb-3">⚡ Ações Rápidas</strong>
        <div class="d-flex gap-2 flex-wrap">
            <a href="/conectafacil/locacoes/nova.php" class="btn btn-primary">➕ Nova Locação</a>
            <a href="/conectafacil/locacoes/index.php?filtro=ativas" class="btn btn-outline-primary">📋 Locações Ativas</a>
            <?php if ($u['perfil']==='admin'): ?>
            <a href="/conectafacil/admin/dispositivos.php?acao=novo" class="btn btn-outline-secondary">📱 Novo Dispositivo</a>
            <a href="/conectafacil/admin/clientes.php?acao=novo" class="btn btn-outline-secondary">👤 Novo Cliente</a>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
