<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/auth.php';

$db = getDB();
$dispositivos = $db->query("SELECT * FROM dispositivos WHERE status='disponivel' ORDER BY marca, modelo")->fetchAll();
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ConectaFácil Locações Tecnológicas</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        :root { --primary:#2563eb; }
        body { font-family:'Segoe UI',system-ui,sans-serif; }
        .navbar-brand span { color:#60a5fa; }
        .hero { background:linear-gradient(135deg,#0f172a 0%,#1e3a5f 60%,#1e4080 100%); color:white; padding:5rem 0 4rem; }
        .hero h1 { font-size:2.8rem; font-weight:800; line-height:1.15; }
        .hero h1 em { color:#60a5fa; font-style:normal; }
        .hero p { color:#94a3b8; font-size:1.1rem; }
        .hero-stat strong { font-size:1.4rem; color:#60a5fa; display:block; }
        .hero-stat span { font-size:.75rem; color:#64748b; }
        .phone-mock { width:160px;height:300px;background:rgba(255,255,255,.05);border:2px solid rgba(255,255,255,.1);border-radius:2rem;display:flex;align-items:center;justify-content:center;font-size:3.5rem; }
        .section-title { font-size:1.9rem; font-weight:700; }
        .device-card { border:1px solid #e2e8f0;border-radius:.75rem;transition:all .2s;overflow:hidden; }
        .device-card:hover { border-color:#2563eb;box-shadow:0 4px 16px rgba(37,99,235,.12);transform:translateY(-3px); }
        .device-card .icon { font-size:2.5rem; }
        .price-value { font-size:1.3rem;font-weight:700;color:#16a34a; }
        .step-num { width:40px;height:40px;background:#2563eb;color:white;border-radius:50%;font-size:1.1rem;font-weight:700;display:flex;align-items:center;justify-content:center;margin:0 auto 1rem; }
        .benefit-icon { font-size:2rem;display:block;margin-bottom:.5rem; }
        .contact-card { border:1px solid #e2e8f0;border-radius:.75rem;text-align:center;padding:1.5rem; }
        footer { background:#0f172a;color:#94a3b8; }
        .navbar { background:#0f172a!important; }
    </style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-dark sticky-top px-4">
    <a class="navbar-brand fw-bold" href="#">📱 Conecta<span>Fácil</span></a>
    <div class="d-flex gap-4 align-items-center">
        <a href="#dispositivos" class="text-secondary text-decoration-none d-none d-md-block" style="font-size:.875rem">Dispositivos</a>
        <a href="#como-funciona" class="text-secondary text-decoration-none d-none d-md-block" style="font-size:.875rem">Como Funciona</a>
        <a href="#contato" class="text-secondary text-decoration-none d-none d-md-block" style="font-size:.875rem">Contato</a>
        <a href="/conectafacil/login.php" class="btn btn-primary btn-sm"><span style="font-size:.8rem">🔒 Área Restrita</span></a>
    </div>
</nav>

<!-- Hero -->
<section class="hero">
    <div class="container">
        <div class="row align-items-center g-5">
            <div class="col-lg-7">
                <h1 class="mb-3">Smartphones e Tablets<br><em>para quando você precisar</em></h1>
                <p class="mb-4">Alugue dispositivos por diárias acessíveis. Perfeito para eventos, viagens ou enquanto seu aparelho está em manutenção.</p>
                <div class="d-flex gap-3 mb-5 flex-wrap">
                    <a href="#dispositivos" class="btn btn-primary btn-lg">📱 Ver Dispositivos</a>
                    <a href="#como-funciona" class="btn btn-outline-light btn-lg">ℹ️ Como Funciona</a>
                </div>
                <div class="d-flex gap-5">
                    <div class="hero-stat"><strong><?= count($dispositivos) ?>+</strong><span>Disponíveis agora</span></div>
                    <div class="hero-stat"><strong>100%</strong><span>Revisados</span></div>
                    <div class="hero-stat"><strong>Rápido</strong><span>Retirada no dia</span></div>
                </div>
            </div>
            <div class="col-lg-5 d-none d-lg-flex justify-content-center">
                <div class="phone-mock">📱</div>
            </div>
        </div>
    </div>
</section>

<!-- Dispositivos -->
<section class="py-5 bg-light" id="dispositivos">
    <div class="container">
        <div class="text-center mb-5">
            <h2 class="section-title">Dispositivos Disponíveis</h2>
            <p class="text-muted">Aparelhos em ótimo estado, prontos para uso imediato</p>
        </div>
        <div class="row g-3">
            <?php if (empty($dispositivos)): ?>
                <div class="col-12 text-center text-muted py-5">
                    <div style="font-size:3rem;opacity:.3">📱</div>
                    <p>Nenhum dispositivo disponível no momento. Entre em contato!</p>
                </div>
            <?php else: ?>
                <?php foreach ($dispositivos as $d): ?>
                <div class="col-sm-6 col-md-4 col-lg-3">
                    <div class="device-card h-100 p-4 text-center bg-white position-relative">
                        <span class="badge bg-success position-absolute top-0 end-0 m-2" style="font-size:.65rem">Disponível</span>
                        <div class="icon mb-2">
                            <?= stripos($d['modelo'], 'iPad') !== false || stripos($d['modelo'], 'Tab') !== false ? '📟' : '📱' ?>
                        </div>
                        <h5 class="mb-1"><?= h($d['modelo']) ?></h5>
                        <p class="text-muted mb-2" style="font-size:.8rem">🏷️ <?= h($d['marca']) ?></p>
                        <?php if ($d['descricao']): ?>
                            <p class="text-muted mb-3" style="font-size:.75rem"><?= h($d['descricao']) ?></p>
                        <?php endif; ?>
                        <div class="mb-3">
                            <span style="font-size:.7rem;color:#94a3b8;display:block;text-transform:uppercase">Diária a partir de</span>
                            <span class="price-value">R$ <?= number_format($d['valor_diaria'], 2, ',', '.') ?></span>
                        </div>
                        <a href="#contato" class="btn btn-primary btn-sm w-100">Solicitar</a>
                    </div>
                </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
</section>

<!-- Como Funciona -->
<section class="py-5" id="como-funciona">
    <div class="container">
        <div class="text-center mb-5">
            <h2 class="section-title">Como Funciona</h2>
            <p class="text-muted">Processo simples em apenas 3 passos</p>
        </div>
        <div class="row g-4 text-center">
            <div class="col-md-4">
                <div class="step-num">1</div>
                <div style="font-size:2.5rem" class="mb-2">📞</div>
                <h5>Entre em Contato</h5>
                <p class="text-muted">Fale conosco por telefone ou WhatsApp e informe o modelo desejado e o período.</p>
            </div>
            <div class="col-md-4">
                <div class="step-num">2</div>
                <div style="font-size:2.5rem" class="mb-2">📝</div>
                <h5>Cadastro e Contrato</h5>
                <p class="text-muted">Faça seu cadastro com documento e assine o contrato com prazo e condições.</p>
            </div>
            <div class="col-md-4">
                <div class="step-num">3</div>
                <div style="font-size:2.5rem" class="mb-2">🤝</div>
                <h5>Retire e Use</h5>
                <p class="text-muted">Retire o dispositivo no mesmo dia e devolva na data combinada.</p>
            </div>
        </div>
    </div>
</section>

<!-- Benefícios -->
<section class="py-5 bg-light">
    <div class="container">
        <div class="text-center mb-5">
            <h2 class="section-title">Por que a ConectaFácil?</h2>
        </div>
        <div class="row g-4 text-center">
            <div class="col-6 col-md-3"><span class="benefit-icon">🛡️</span><h6>Aparelhos Garantidos</h6><p class="text-muted small">Revisados e testados antes de cada locação.</p></div>
            <div class="col-6 col-md-3"><span class="benefit-icon">💰</span><h6>Preços Acessíveis</h6><p class="text-muted small">Diárias competitivas com condições especiais.</p></div>
            <div class="col-6 col-md-3"><span class="benefit-icon">⚡</span><h6>Entrega Rápida</h6><p class="text-muted small">Retirada no mesmo dia após confirmação.</p></div>
            <div class="col-6 col-md-3"><span class="benefit-icon">🎧</span><h6>Suporte Técnico</h6><p class="text-muted small">Equipe disponível durante todo o período.</p></div>
        </div>
    </div>
</section>

<!-- Contato -->
<section class="py-5" id="contato">
    <div class="container">
        <div class="text-center mb-5">
            <h2 class="section-title">Entre em Contato</h2>
            <p class="text-muted">Estamos prontos para atender você</p>
        </div>
        <div class="row g-3 justify-content-center">
            <div class="col-6 col-md-3"><div class="contact-card"><div style="font-size:2rem">📞</div><h6 class="mt-2">Telefone</h6><p class="text-muted mb-0" style="font-size:.85rem">(11) 3000-0000</p></div></div>
            <div class="col-6 col-md-3"><div class="contact-card"><div style="font-size:2rem">💬</div><h6 class="mt-2">WhatsApp</h6><p class="text-muted mb-0" style="font-size:.85rem">(11) 99999-0000</p></div></div>
            <div class="col-6 col-md-3"><div class="contact-card"><div style="font-size:2rem">✉️</div><h6 class="mt-2">E-mail</h6><p class="text-muted mb-0" style="font-size:.85rem">contato@conectafacil.com</p></div></div>
            <div class="col-6 col-md-3"><div class="contact-card"><div style="font-size:2rem">🕐</div><h6 class="mt-2">Horário</h6><p class="text-muted mb-0" style="font-size:.85rem">Seg-Sex: 8h–18h<br>Sáb: 9h–13h</p></div></div>
        </div>
    </div>
</section>

<footer class="py-3">
    <div class="container d-flex justify-content-between align-items-center flex-wrap gap-2">
        <p class="mb-0" style="font-size:.8rem">&copy; <?= date('Y') ?> ConectaFácil Locações Tecnológicas</p>
        <a href="/conectafacil/login.php" style="font-size:.8rem;color:#60a5fa;text-decoration:none">🔒 Área Administrativa</a>
    </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
