<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/db.php';

iniciarSessao();
if (usuarioLogado()) { header('Location: /conectafacil/dashboard.php'); exit; }

$erro = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $senha = $_POST['senha'] ?? '';

    if (!$email || !$senha) {
        $erro = 'Preencha todos os campos.';
    } else {
        $db = getDB();
        $st = $db->prepare("SELECT * FROM usuarios WHERE email=? AND ativo=1");
        $st->execute([$email]);
        $user = $st->fetch();

        if ($user && password_verify($senha, $user['senha'])) {
            $_SESSION['usuario'] = ['id'=>$user['id'],'nome'=>$user['nome'],'email'=>$user['email'],'perfil'=>$user['perfil']];
            header('Location: /conectafacil/dashboard.php');
            exit;
        } else {
            $erro = 'E-mail ou senha inválidos.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login — ConectaFácil</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { min-height:100vh;background:linear-gradient(135deg,#0f172a 0%,#1e3a5f 100%);display:flex;align-items:center;justify-content:center; }
        .login-card { background:white;border-radius:1rem;padding:2rem;width:100%;max-width:400px;box-shadow:0 10px 25px rgba(0,0,0,.2); }
        .logo-box { width:52px;height:52px;background:#2563eb;border-radius:.75rem;display:flex;align-items:center;justify-content:center;font-size:1.4rem;margin:0 auto .75rem; }
        .hint { background:#f8fafc;border-radius:.375rem;padding:.75rem;font-size:.75rem;color:#64748b;margin-top:.75rem; }
        .hint code { background:#e2e8f0;padding:.1rem .3rem;border-radius:3px; }
    </style>
</head>
<body>
<div class="login-card">
    <div class="text-center mb-4">
        <div class="logo-box">📱</div>
        <h5 class="fw-bold mb-0">ConectaFácil</h5>
        <small class="text-muted">Locações Tecnológicas</small>
    </div>

    <?php if ($erro): ?>
        <div class="alert alert-danger py-2" style="font-size:.875rem">❌ <?= h($erro) ?></div>
    <?php endif; ?>
    <?php
    $flash = getFlash();
    if ($flash): ?>
        <div class="alert alert-<?= $flash['tipo']==='success'?'success':'danger' ?> py-2" style="font-size:.875rem"><?= h($flash['msg']) ?></div>
    <?php endif; ?>

    <form method="POST">
        <div class="mb-3">
            <label class="form-label fw-semibold" style="font-size:.85rem">E-mail</label>
            <input type="email" name="email" class="form-control" placeholder="seu@email.com" required autofocus value="<?= h($_POST['email'] ?? '') ?>">
        </div>
        <div class="mb-3">
            <label class="form-label fw-semibold" style="font-size:.85rem">Senha</label>
            <input type="password" name="senha" class="form-control" placeholder="••••••••" required>
        </div>
        <button type="submit" class="btn btn-primary w-100">🔐 Entrar</button>
    </form>

    <div class="hint text-center">
        <strong>Acesso padrão:</strong><br>
        Admin: admin@conectafacil.com / <code>admin123</code><br>
        Operador: operador@conectafacil.com / <code>oper123</code>
    </div>

    <div class="text-center mt-3">
        <a href="/conectafacil/index.php" style="font-size:.85rem;color:#2563eb;text-decoration:none">← Voltar ao site</a>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
