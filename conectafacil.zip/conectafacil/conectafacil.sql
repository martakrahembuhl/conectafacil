-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 11/06/2026 às 02:56
-- Versão do servidor: 10.4.32-MariaDB
-- Versão do PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `conectafacil`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `clientes`
--

CREATE TABLE `clientes` (
  `id` int(11) NOT NULL,
  `nome` varchar(150) NOT NULL,
  `cpf` varchar(14) DEFAULT NULL,
  `telefone` varchar(20) DEFAULT NULL,
  `email` varchar(150) DEFAULT NULL,
  `endereco` text DEFAULT NULL,
  `criado_em` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `clientes`
--

INSERT INTO `clientes` (`id`, `nome`, `cpf`, `telefone`, `email`, `endereco`, `criado_em`) VALUES
(1, 'João Silva', '123.456.789-00', '(11) 99999-1111', 'joao@email.com', 'Rua das Flores, 123 - São Paulo/SP', '2026-06-11 00:34:17'),
(2, 'Maria Oliveira', '987.654.321-00', '(11) 98888-2222', 'maria@email.com', 'Av. Paulista, 456 - São Paulo/SP', '2026-06-11 00:34:17'),
(3, 'Carlos Santos', '456.789.123-00', '(21) 97777-3333', 'carlos@email.com', 'Rua do Comércio, 789 - Rio de Janeiro/RJ', '2026-06-11 00:34:17'),
(4, 'Manuel Augusto', '543.923.698-89', '(11) 97878-1232', 'marta.h.souza@aluno.senai.br', 'estrelas', '2026-06-11 00:47:41');

-- --------------------------------------------------------

--
-- Estrutura para tabela `dispositivos`
--

CREATE TABLE `dispositivos` (
  `id` int(11) NOT NULL,
  `modelo` varchar(100) NOT NULL,
  `marca` varchar(100) NOT NULL,
  `imei` varchar(20) DEFAULT NULL,
  `valor_diaria` decimal(10,2) NOT NULL,
  `status` enum('disponivel','alugado','manutencao') DEFAULT 'disponivel',
  `descricao` text DEFAULT NULL,
  `criado_em` timestamp NOT NULL DEFAULT current_timestamp(),
  `atualizado_em` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `dispositivos`
--

INSERT INTO `dispositivos` (`id`, `modelo`, `marca`, `imei`, `valor_diaria`, `status`, `descricao`, `criado_em`, `atualizado_em`) VALUES
(1, 'iPhone 13', 'Apple', NULL, 45.00, 'disponivel', 'iPhone 13 128GB, excelente estado', '2026-06-11 00:34:17', '2026-06-11 00:34:17'),
(2, 'Galaxy S23', 'Samsung', NULL, 40.00, 'disponivel', 'Samsung Galaxy S23 256GB', '2026-06-11 00:34:17', '2026-06-11 00:34:17'),
(3, 'Moto G84', 'Motorola', NULL, 25.00, 'alugado', 'Motorola Moto G84 256GB', '2026-06-11 00:34:17', '2026-06-11 00:49:27'),
(4, 'iPad Air 5', 'Apple', NULL, 60.00, 'disponivel', 'iPad Air 5ª geração 64GB Wi-Fi', '2026-06-11 00:34:17', '2026-06-11 00:34:17'),
(5, 'Galaxy Tab S8', 'Samsung', NULL, 55.00, 'disponivel', 'Samsung Galaxy Tab S8 256GB', '2026-06-11 00:34:17', '2026-06-11 00:34:17'),
(6, 'Redmi Note 12', 'Xiaomi', NULL, 20.00, 'disponivel', 'Xiaomi Redmi Note 12 128GB', '2026-06-11 00:34:17', '2026-06-11 00:34:17'),
(7, 'iPhone 14 Pro', 'Apple', NULL, 65.00, 'disponivel', 'iPhone 14 Pro 256GB', '2026-06-11 00:34:17', '2026-06-11 00:34:17'),
(8, 'Galaxy A54', 'Samsung', NULL, 30.00, 'disponivel', 'Samsung Galaxy A54 128GB', '2026-06-11 00:34:17', '2026-06-11 00:34:17'),
(9, 'iPad Air 5', 'Apple', NULL, 45.00, 'disponivel', NULL, '2026-06-11 00:46:37', '2026-06-11 00:46:37');

-- --------------------------------------------------------

--
-- Estrutura para tabela `locacoes`
--

CREATE TABLE `locacoes` (
  `id` int(11) NOT NULL,
  `cliente_id` int(11) NOT NULL,
  `dispositivo_id` int(11) NOT NULL,
  `usuario_id` int(11) NOT NULL,
  `data_retirada` date NOT NULL,
  `data_prevista_devolucao` date NOT NULL,
  `data_devolucao` date DEFAULT NULL,
  `status` enum('ativa','finalizada') DEFAULT 'ativa',
  `dias_locados` int(11) DEFAULT NULL,
  `valor_total` decimal(10,2) DEFAULT NULL,
  `multa_atraso` decimal(10,2) DEFAULT 0.00,
  `taxa_dano` decimal(10,2) DEFAULT 0.00,
  `houve_dano` tinyint(1) DEFAULT 0,
  `descricao_dano` text DEFAULT NULL,
  `valor_final` decimal(10,2) DEFAULT NULL,
  `observacoes` text DEFAULT NULL,
  `criado_em` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `locacoes`
--

INSERT INTO `locacoes` (`id`, `cliente_id`, `dispositivo_id`, `usuario_id`, `data_retirada`, `data_prevista_devolucao`, `data_devolucao`, `status`, `dias_locados`, `valor_total`, `multa_atraso`, `taxa_dano`, `houve_dano`, `descricao_dano`, `valor_final`, `observacoes`, `criado_em`) VALUES
(1, 3, 3, 1, '2026-06-11', '2026-12-05', NULL, 'ativa', 177, 4425.00, 0.00, 0.00, 0, NULL, 4425.00, 'sem fiado', '2026-06-11 00:49:27');

-- --------------------------------------------------------

--
-- Estrutura para tabela `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `email` varchar(150) NOT NULL,
  `senha` varchar(255) NOT NULL,
  `perfil` enum('admin','operador') DEFAULT 'operador',
  `ativo` tinyint(1) DEFAULT 1,
  `criado_em` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `usuarios`
--

INSERT INTO `usuarios` (`id`, `nome`, `email`, `senha`, `perfil`, `ativo`, `criado_em`) VALUES
(1, 'Administrador', 'admin@conectafacil.com', '$2y$10$dB6JW28dBWBXXQVDubhJmOJ5An9S7cOOF0qlpSLqtbX8KvNGRfEAC', 'admin', 1, '2026-06-11 00:34:17'),
(2, 'Marta Helena Krahembuhl Venancio Estevam de Souza', 'operador@conectafacil.com', '$2y$10$2PZf4HDK/uxEEnzhgIi9iOsbT7QrR9VKmltUGqXcvmxELUZ.IhBr6', 'operador', 1, '2026-06-11 00:34:17');

--
-- Índices para tabelas despejadas
--

--
-- Índices de tabela `clientes`
--
ALTER TABLE `clientes`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `cpf` (`cpf`);

--
-- Índices de tabela `dispositivos`
--
ALTER TABLE `dispositivos`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `imei` (`imei`);

--
-- Índices de tabela `locacoes`
--
ALTER TABLE `locacoes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `cliente_id` (`cliente_id`),
  ADD KEY `dispositivo_id` (`dispositivo_id`),
  ADD KEY `usuario_id` (`usuario_id`);

--
-- Índices de tabela `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT para tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `clientes`
--
ALTER TABLE `clientes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de tabela `dispositivos`
--
ALTER TABLE `dispositivos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT de tabela `locacoes`
--
ALTER TABLE `locacoes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de tabela `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Restrições para tabelas despejadas
--

--
-- Restrições para tabelas `locacoes`
--
ALTER TABLE `locacoes`
  ADD CONSTRAINT `locacoes_ibfk_1` FOREIGN KEY (`cliente_id`) REFERENCES `clientes` (`id`),
  ADD CONSTRAINT `locacoes_ibfk_2` FOREIGN KEY (`dispositivo_id`) REFERENCES `dispositivos` (`id`),
  ADD CONSTRAINT `locacoes_ibfk_3` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
