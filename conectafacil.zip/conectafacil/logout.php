<?php
session_start();
session_destroy();
header('Location: /conectafacil/login.php');
exit;
