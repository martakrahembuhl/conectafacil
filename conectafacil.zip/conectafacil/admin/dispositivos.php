<?php
require_once __DIR__ . '/../../config.php';
require_once __DIR__ . '/../../includes/auth.php';
require_once __DIR__ . '/../../includes/db.php';
$pageTitle = 'Dispositivos — ConectaFácil';
$u = exigirAdmin();
$db = getDB();

$acao = $_GET['acao'] ?? 'listar';
$id   = (int)($_GET['id'] ?? 0);
$erro = '';

// PROCESSAR FORMULÁRIOS
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $modelo      = trim($_POST['modelo'] ?? '');
    $marca       = trim($_POST['marca'] ?? '');
    $imei        = trim($_POST['imei'] ?? '') ?: null;
    $valor       = (float)str_replace(',', '.', $_POST['valor_diaria'] ?? 0);
    $status      = $_POST['status'] ?? 'disponivel';
    $descricao   = trim($_POST['descricao'] ?? '') ?: null;

    if (!$modelo || !$marca || $valor <= 0) {
        $erro = 'Preencha todos os campos obrigatórios.';
        $acao = $_POST['acao_form'];
    } else {
        try {
            if ($_POST['acao_form'] === 'novo') {
                $db->prepare("INSERT INTO dispositivos (modelo,marca,imei,valor_diaria,status,descricao) VALUES (?,?,?,?,?,?)")
                   ->execute([$modelo,$marca,$imei,$valor,'disponivel',$descricao]);
                setFlash('success', 'Dispositivo cadastrado com sucesso!');
            } else {
                $db->prepare("UPDATE dispositivos SET modelo=?,marca=?,imei=?,valor_diaria=?,status=?,descricao=? WHERE id=?")
                   ->execute([$modelo,$marca,$imei,$valor,$status,$descricao,$_POST['id']]);
                setFlash('success', 'Dispositivo atualizado!');
            }
        } catch (PDOException $e) {
            $erro = str_contains($e->getMessage(), 'Duplicate') ? 'IMEI já cadastrado.' : 'Erro ao salvar.';
            $acao = $_POST['acao_form'];
        }
        if (!$erro) { header('Location: /conectafacil/admin/dispositivos.php'); exit; }
    }
}

if ($acao === 'excluir' && $id) {
    $ativo = $db->prepare("SELECT COUNT(*) FROM locacoes WHERE dispositivo_id=? AND status='ativa'");
    $ativo->execute([$id]);
    if ($ativo->fetchColumn() > 0) {
        setFlash('error', 'Não é possível excluir um dispositivo com locação ativa.');
    } else {
        $db->prepare("DELETE FROM dispositivos WHERE id=?")->execute([$id]);
        setFlash('success', 'Dispositivo removido.');
    }
    header('Location: /conectafacil/admin/dispositivos.php'); exit;
}

$disp = null;
if (($acao === 'editar') && $id) {
    $disp = $db->prepare("SELECT * FROM dispositivos WHERE id=?");
    $disp->execute([$id]);
    $disp = $disp->fetch();
    if (!$disp) { setFlash('error','Não encontrado.'); header('Location: /conectafacil/admin/dispositivos.php'); exit; }
}

// LISTAR
$todos = $db->query("SELECT * FROM dispositivos ORDER BY marca,modelo")->fetchAll();
$countDisp = count(array_filter($todos, fn($d)=>$d['status']==='disponivel'));
$countAlug = count(array_filter($todos, fn($d)=>$d['status']==='alugado'));
$countMan  = count(array_filter($todos, fn($d)=>$d['status']==='manutencao'));
require_once __DIR__ . '/../includes/header.php';
?>

<div class="d-flex align-items-center justify-content-between page-header">
    <div>
        <h4 class="fw-bold mb-1">📱 Dispositivos</h4>
        <p class="text-muted mb-0" style="font-size:.875rem">Gerenciar smartphones e tablets</p>
    </div>
    <a href="?acao=novo" class="btn btn-primary">➕ Novo Dispositivo</a>
</div>

<?php if ($acao === 'novo' || $acao === 'editar'): ?>
<!-- FORMULÁRIO -->
<div class="card mb-4" style="max-width:700px">
    <div class="card-header"><strong><?= $acao==='novo'?'➕ Novo Dispositivo':'✏️ Editar Dispositivo' ?></strong></div>
    <div class="card-body">
        <?php if ($erro): ?><div class="alert alert-danger">❌ <?= h($erro) ?></div><?php endif; ?>
        <form method="POST">
            <input type="hidden" name="acao_form" value="<?= $acao ?>">
            <?php if ($disp): ?><input type="hidden" name="id" value="<?= $disp['id'] ?>"><?php endif; ?>
            <div class="row g-3">
                <div class="col-md-6">
                    <label class="form-label">Modelo <span class="text-danger">*</span></label>
                    <input type="text" name="modelo" class="form-control" value="<?= h($disp['modelo'] ?? $_POST['modelo'] ?? '') ?>" placeholder="Ex: iPhone 13" required>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Marca <span class="text-danger">*</span></label>
                    <input type="text" name="marca" class="form-control" value="<?= h($disp['marca'] ?? $_POST['marca'] ?? '') ?>" placeholder="Apple, Samsung..." required>
                </div>
                <div class="col-md-6">
                    <label class="form-label">IMEI</label>
                    <input type="text" name="imei" class="form-control" value="<?= h($disp['imei'] ?? '') ?>" placeholder="Opcional" maxlength="20">
                </div>
                <div class="col-md-6">
                    <label class="form-label">Valor da Diária (R$) <span class="text-danger">*</span></label>
                    <input type="number" name="valor_diaria" class="form-control" value="<?= h($disp['valor_diaria'] ?? '') ?>" step="0.01" min="0" required>
                </div>
                <?php if ($acao === 'editar'): ?>
                <div class="col-md-6">
                    <label class="form-label">Status</label>
                    <select name="status" class="form-select">
                        <option value="disponivel" <?= ($disp['status']??'')==='disponivel'?'selected':'' ?>>Disponível</option>
                        <option value="alugado"    <?= ($disp['status']??'')==='alugado'?'selected':'' ?>>Alugado</option>
                        <option value="manutencao" <?= ($disp['status']??'')==='manutencao'?'selected':'' ?>>Manutenção</option>
                    </select>
                </div>
                <?php endif; ?>
                <div class="col-12">
                    <label class="form-label">Descrição</label>
                    <textarea name="descricao" class="form-control" rows="2" placeholder="Detalhes do aparelho..."><?= h($disp['descricao'] ?? '') ?></textarea>
                </div>
            </div>
            <div class="d-flex gap-2 justify-content-end mt-3">
                <a href="/conectafacil/admin/dispositivos.php" class="btn btn-outline-secondary">Cancelar</a>
                <button type="submit" class="btn btn-primary">💾 <?= $acao==='novo'?'Cadastrar':'Salvar' ?></button>
            </div>
        </form>
    </div>
</div>
<?php endif; ?>

<!-- FILTROS -->
<div class="d-flex gap-2 mb-3 flex-wrap">
    <button class="btn btn-sm btn-outline-secondary" onclick="filtrar('todos')">Todos (<?= count($todos) ?>)</button>
    <button class="btn btn-sm btn-outline-success" onclick="filtrar('disponivel')">✅ Disponíveis (<?= $countDisp ?>)</button>
    <button class="btn btn-sm btn-outline-warning" onclick="filtrar('alugado')">📤 Alugados (<?= $countAlug ?>)</button>
    <button class="btn btn-sm btn-outline-secondary" onclick="filtrar('manutencao')">🔧 Manutenção (<?= $countMan ?>)</button>
    <input type="text" class="form-control form-control-sm ms-auto" style="max-width:200px" placeholder="Buscar..." oninput="buscar(this.value)">
</div>

<div class="card">
    <div class="table-responsive">
        <table class="table table-hover mb-0" id="tabela">
            <thead><tr><th>#</th><th>Modelo</th><th>Marca</th><th>IMEI</th><th>Diária</th><th>Status</th><th>Ações</th></tr></thead>
            <tbody>
            <?php foreach ($todos as $d): ?>
                <tr data-status="<?= $d['status'] ?>">
                    <td><?= $d['id'] ?></td>
                    <td>
                        <strong><?= h($d['modelo']) ?></strong>
                        <?php if ($d['descricao']): ?><br><small class="text-muted"><?= h(mb_substr($d['descricao'],0,50)) ?></small><?php endif; ?>
                    </td>
                    <td><?= h($d['marca']) ?></td>
                    <td><?= h($d['imei'] ?? '—') ?></td>
                    <td><?= fmt($d['valor_diaria']) ?></td>
                    <td>
                        <span class="badge badge-<?= $d['status'] ?>">
                            <?= $d['status']==='disponivel'?'Disponível':($d['status']==='alugado'?'Alugado':'Manutenção') ?>
                        </span>
                    </td>
                    <td>
                        <a href="?acao=editar&id=<?= $d['id'] ?>" class="btn btn-sm btn-outline-primary">✏️</a>
                        <?php if ($d['status'] !== 'alugado'): ?>
                        <a href="?acao=excluir&id=<?= $d['id'] ?>" class="btn btn-sm btn-outline-danger"
                           onclick="return confirmDel('Excluir dispositivo <?= h($d['modelo']) ?>?')">🗑️</a>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<script>
function filtrar(status) {
    document.querySelectorAll('#tabela tbody tr').forEach(r => {
        r.style.display = (status==='todos' || r.dataset.status===status) ? '' : 'none';
    });
}
function buscar(q) {
    q = q.toLowerCase();
    document.querySelectorAll('#tabela tbody tr').forEach(r => {
        r.style.display = r.textContent.toLowerCase().includes(q) ? '' : 'none';
    });
}
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
