<?php
require_once __DIR__ . '/../../config.php';
require_once __DIR__ . '/../../includes/auth.php';
require_once __DIR__ . '/../../includes/db.php';
$pageTitle = 'Usuários — ConectaFácil';
$u = exigirAdmin();
$db = getDB();

$acao = $_GET['acao'] ?? 'listar';
$id   = (int)($_GET['id'] ?? 0);
$erro = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome   = trim($_POST['nome'] ?? '');
    $email  = trim($_POST['email'] ?? '');
    $senha  = $_POST['senha'] ?? '';
    $perfil = $_POST['perfil'] ?? 'operador';
    $ativo  = isset($_POST['ativo']) ? 1 : 0;

    if (!$nome || !$email || !$perfil) { $erro = 'Preencha os campos obrigatórios.'; $acao=$_POST['acao_form']; }
    elseif ($_POST['acao_form']==='novo' && !$senha) { $erro='Senha obrigatória.'; $acao='novo'; }
    elseif ($senha && strlen($senha)<6) { $erro='Senha deve ter pelo menos 6 caracteres.'; $acao=$_POST['acao_form']; }
    else {
        try {
            if ($_POST['acao_form'] === 'novo') {
                $hash = password_hash($senha, PASSWORD_DEFAULT);
                $db->prepare("INSERT INTO usuarios (nome,email,senha,perfil) VALUES (?,?,?,?)")->execute([$nome,$email,$hash,$perfil]);
                setFlash('success','Usuário criado!');
            } else {
                if ($senha) {
                    $hash = password_hash($senha, PASSWORD_DEFAULT);
                    $db->prepare("UPDATE usuarios SET nome=?,email=?,senha=?,perfil=?,ativo=? WHERE id=?")->execute([$nome,$email,$hash,$perfil,$ativo,$_POST['id']]);
                } else {
                    $db->prepare("UPDATE usuarios SET nome=?,email=?,perfil=?,ativo=? WHERE id=?")->execute([$nome,$email,$perfil,$ativo,$_POST['id']]);
                }
                setFlash('success','Usuário atualizado!');
            }
        } catch (PDOException $e) {
            $erro = str_contains($e->getMessage(),'Duplicate') ? 'E-mail já cadastrado.' : 'Erro ao salvar.';
            $acao = $_POST['acao_form'];
        }
        if (!$erro) { header('Location: /conectafacil/admin/usuarios.php'); exit; }
    }
}

if ($acao === 'excluir' && $id) {
    if ($id === (int)$u['id']) { setFlash('error','Você não pode excluir seu próprio usuário.'); }
    else { $db->prepare("DELETE FROM usuarios WHERE id=?")->execute([$id]); setFlash('success','Usuário removido.'); }
    header('Location: /conectafacil/admin/usuarios.php'); exit;
}

$edit = null;
if ($acao === 'editar' && $id) {
    $st = $db->prepare("SELECT id,nome,email,perfil,ativo FROM usuarios WHERE id=?"); $st->execute([$id]); $edit = $st->fetch();
    if (!$edit) { setFlash('error','Não encontrado.'); header('Location: /conectafacil/admin/usuarios.php'); exit; }
}

$usuarios = $db->query("SELECT id,nome,email,perfil,ativo,criado_em FROM usuarios ORDER BY nome")->fetchAll();
require_once __DIR__ . '/../includes/header.php';
?>

<div class="d-flex align-items-center justify-content-between page-header">
    <div>
        <h4 class="fw-bold mb-1">🛡️ Usuários</h4>
        <p class="text-muted mb-0" style="font-size:.875rem">Gerenciar acessos e permissões</p>
    </div>
    <a href="?acao=novo" class="btn btn-primary">➕ Novo Usuário</a>
</div>

<?php if ($acao === 'novo' || $acao === 'editar'): ?>
<div class="card mb-4" style="max-width:600px">
    <div class="card-header"><strong><?= $acao==='novo'?'➕ Novo Usuário':'✏️ Editar Usuário' ?></strong></div>
    <div class="card-body">
        <?php if ($erro): ?><div class="alert alert-danger">❌ <?= h($erro) ?></div><?php endif; ?>
        <form method="POST">
            <input type="hidden" name="acao_form" value="<?= $acao ?>">
            <?php if ($edit): ?><input type="hidden" name="id" value="<?= $edit['id'] ?>"><?php endif; ?>
            <div class="row g-3">
                <div class="col-12">
                    <label class="form-label">Nome <span class="text-danger">*</span></label>
                    <input type="text" name="nome" class="form-control" value="<?= h($edit['nome'] ?? '') ?>" required>
                </div>
                <div class="col-md-6">
                    <label class="form-label">E-mail <span class="text-danger">*</span></label>
                    <input type="email" name="email" class="form-control" value="<?= h($edit['email'] ?? '') ?>" required>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Perfil</label>
                    <select name="perfil" class="form-select">
                        <option value="operador" <?= ($edit['perfil']??'')==='operador'?'selected':'' ?>>Operador</option>
                        <option value="admin"    <?= ($edit['perfil']??'')==='admin'?'selected':'' ?>>Administrador</option>
                    </select>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Senha <?= $acao==='editar'?'(deixe em branco para manter)':'' ?> <?= $acao==='novo'?'<span class="text-danger">*</span>':'' ?></label>
                    <input type="password" name="senha" class="form-control" placeholder="Mínimo 6 caracteres" <?= $acao==='novo'?'required':'' ?> minlength="6">
                </div>
                <?php if ($acao === 'editar'): ?>
                <div class="col-md-6 d-flex align-items-end">
                    <div class="form-check mb-1">
                        <input type="checkbox" name="ativo" class="form-check-input" id="chkAtivo" <?= $edit['ativo']?'checked':'' ?>>
                        <label for="chkAtivo" class="form-check-label">Usuário Ativo</label>
                    </div>
                </div>
                <?php endif; ?>
            </div>
            <div class="d-flex gap-2 justify-content-end mt-3">
                <a href="/conectafacil/admin/usuarios.php" class="btn btn-outline-secondary">Cancelar</a>
                <button type="submit" class="btn btn-primary">💾 Salvar</button>
            </div>
        </form>
    </div>
</div>
<?php endif; ?>

<div class="card">
    <div class="table-responsive">
        <table class="table table-hover mb-0">
            <thead><tr><th>#</th><th>Nome</th><th>E-mail</th><th>Perfil</th><th>Status</th><th>Criado em</th><th>Ações</th></tr></thead>
            <tbody>
            <?php foreach ($usuarios as $usr): ?>
                <tr>
                    <td><?= $usr['id'] ?></td>
                    <td><strong><?= h($usr['nome']) ?></strong></td>
                    <td><?= h($usr['email']) ?></td>
                    <td><span class="badge <?= $usr['perfil']==='admin'?'bg-primary':'bg-success' ?>"><?= $usr['perfil']==='admin'?'Administrador':'Operador' ?></span></td>
                    <td><span class="badge <?= $usr['ativo']?'bg-success':'bg-secondary' ?>"><?= $usr['ativo']?'Ativo':'Inativo' ?></span></td>
                    <td><?= fmtData($usr['criado_em']) ?></td>
                    <td>
                        <a href="?acao=editar&id=<?= $usr['id'] ?>" class="btn btn-sm btn-outline-primary">✏️</a>
                        <?php if ($usr['id'] !== (int)$u['id']): ?>
                        <a href="?acao=excluir&id=<?= $usr['id'] ?>" class="btn btn-sm btn-outline-danger"
                           onclick="return confirmDel('Excluir <?= h($usr['nome']) ?>?')">🗑️</a>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
