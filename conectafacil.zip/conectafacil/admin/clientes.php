<?php
require_once __DIR__ . '/../../config.php';
require_once __DIR__ . '/../../includes/auth.php';
require_once __DIR__ . '/../../includes/db.php';
$pageTitle = 'Clientes — ConectaFácil';
$u = exigirLogin();
$db = getDB();

$acao = $_GET['acao'] ?? 'listar';
$id   = (int)($_GET['id'] ?? 0);
$erro = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome     = trim($_POST['nome'] ?? '');
    $cpf      = trim($_POST['cpf'] ?? '') ?: null;
    $telefone = trim($_POST['telefone'] ?? '') ?: null;
    $email    = trim($_POST['email'] ?? '') ?: null;
    $endereco = trim($_POST['endereco'] ?? '') ?: null;

    if (!$nome) {
        $erro = 'Nome é obrigatório.';
        $acao = $_POST['acao_form'];
    } else {
        try {
            if ($_POST['acao_form'] === 'novo') {
                $db->prepare("INSERT INTO clientes (nome,cpf,telefone,email,endereco) VALUES (?,?,?,?,?)")
                   ->execute([$nome,$cpf,$telefone,$email,$endereco]);
                setFlash('success', 'Cliente cadastrado!');
            } else {
                $db->prepare("UPDATE clientes SET nome=?,cpf=?,telefone=?,email=?,endereco=? WHERE id=?")
                   ->execute([$nome,$cpf,$telefone,$email,$endereco,$_POST['id']]);
                setFlash('success', 'Cliente atualizado!');
            }
        } catch (PDOException $e) {
            $erro = str_contains($e->getMessage(),'Duplicate') ? 'CPF já cadastrado.' : 'Erro ao salvar.';
            $acao = $_POST['acao_form'];
        }
        if (!$erro) { header('Location: /conectafacil/admin/clientes.php'); exit; }
    }
}

if ($acao === 'excluir' && $id) {
    $at = $db->prepare("SELECT COUNT(*) FROM locacoes WHERE cliente_id=? AND status='ativa'");
    $at->execute([$id]);
    if ($at->fetchColumn() > 0) { setFlash('error','Cliente possui locação ativa.'); }
    else { $db->prepare("DELETE FROM clientes WHERE id=?")->execute([$id]); setFlash('success','Cliente removido.'); }
    header('Location: /conectafacil/admin/clientes.php'); exit;
}

$cli = null;
if (($acao === 'editar') && $id) {
    $st = $db->prepare("SELECT * FROM clientes WHERE id=?"); $st->execute([$id]); $cli = $st->fetch();
    if (!$cli) { setFlash('error','Não encontrado.'); header('Location: /conectafacil/admin/clientes.php'); exit; }
}

$busca = trim($_GET['busca'] ?? '');
if ($busca) {
    $st = $db->prepare("SELECT * FROM clientes WHERE nome LIKE ? OR cpf LIKE ? OR email LIKE ? ORDER BY nome");
    $st->execute(["%$busca%","%$busca%","%$busca%"]);
} else {
    $st = $db->query("SELECT * FROM clientes ORDER BY nome");
}
$clientes = $st->fetchAll();
require_once __DIR__ . '/../includes/header.php';
?>

<div class="d-flex align-items-center justify-content-between page-header">
    <div>
        <h4 class="fw-bold mb-1">👥 Clientes</h4>
        <p class="text-muted mb-0" style="font-size:.875rem">Gerenciar clientes cadastrados</p>
    </div>
    <a href="?acao=novo" class="btn btn-primary">➕ Novo Cliente</a>
</div>

<?php if ($acao === 'novo' || $acao === 'editar'): ?>
<div class="card mb-4" style="max-width:700px">
    <div class="card-header"><strong><?= $acao==='novo'?'➕ Novo Cliente':'✏️ Editar Cliente' ?></strong></div>
    <div class="card-body">
        <?php if ($erro): ?><div class="alert alert-danger">❌ <?= h($erro) ?></div><?php endif; ?>
        <form method="POST">
            <input type="hidden" name="acao_form" value="<?= $acao ?>">
            <?php if ($cli): ?><input type="hidden" name="id" value="<?= $cli['id'] ?>"><?php endif; ?>
            <div class="row g-3">
                <div class="col-12">
                    <label class="form-label">Nome Completo <span class="text-danger">*</span></label>
                    <input type="text" name="nome" class="form-control" value="<?= h($cli['nome'] ?? '') ?>" required placeholder="Nome completo">
                </div>
                <div class="col-md-6">
                    <label class="form-label">CPF</label>
                    <input type="text" name="cpf" class="form-control" value="<?= h($cli['cpf'] ?? '') ?>" placeholder="000.000.000-00" maxlength="14">
                </div>
                <div class="col-md-6">
                    <label class="form-label">Telefone</label>
                    <input type="text" name="telefone" class="form-control" value="<?= h($cli['telefone'] ?? '') ?>" placeholder="(00) 00000-0000">
                </div>
                <div class="col-md-6">
                    <label class="form-label">E-mail</label>
                    <input type="email" name="email" class="form-control" value="<?= h($cli['email'] ?? '') ?>" placeholder="email@exemplo.com">
                </div>
                <div class="col-12">
                    <label class="form-label">Endereço</label>
                    <textarea name="endereco" class="form-control" rows="2" placeholder="Rua, número, bairro..."><?= h($cli['endereco'] ?? '') ?></textarea>
                </div>
            </div>
            <div class="d-flex gap-2 justify-content-end mt-3">
                <a href="/conectafacil/admin/clientes.php" class="btn btn-outline-secondary">Cancelar</a>
                <button type="submit" class="btn btn-primary">💾 Salvar</button>
            </div>
        </form>
    </div>
</div>
<?php endif; ?>

<!-- Busca -->
<form method="GET" class="d-flex gap-2 mb-3">
    <input type="hidden" name="acao" value="listar">
    <input type="text" name="busca" class="form-control" style="max-width:300px" placeholder="Buscar por nome, CPF ou e-mail..." value="<?= h($busca) ?>">
    <button class="btn btn-outline-primary">🔍 Buscar</button>
    <?php if ($busca): ?><a href="/conectafacil/admin/clientes.php" class="btn btn-outline-secondary">✖ Limpar</a><?php endif; ?>
</form>

<div class="card">
    <div class="table-responsive">
        <table class="table table-hover mb-0">
            <thead><tr><th>#</th><th>Nome</th><th>CPF</th><th>Telefone</th><th>E-mail</th><th>Ações</th></tr></thead>
            <tbody>
            <?php if (empty($clientes)): ?>
                <tr><td colspan="6" class="text-center text-muted py-4">Nenhum cliente encontrado.</td></tr>
            <?php else: ?>
            <?php foreach ($clientes as $c): ?>
                <tr>
                    <td><?= $c['id'] ?></td>
                    <td><strong><?= h($c['nome']) ?></strong></td>
                    <td><?= h($c['cpf'] ?? '—') ?></td>
                    <td><?= h($c['telefone'] ?? '—') ?></td>
                    <td><?= h($c['email'] ?? '—') ?></td>
                    <td>
                        <a href="?acao=editar&id=<?= $c['id'] ?>" class="btn btn-sm btn-outline-primary">✏️</a>
                        <a href="?acao=excluir&id=<?= $c['id'] ?>" class="btn btn-sm btn-outline-danger"
                           onclick="return confirmDel('Excluir cliente <?= h($c['nome']) ?>?')">🗑️</a>
                    </td>
                </tr>
            <?php endforeach; ?>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
