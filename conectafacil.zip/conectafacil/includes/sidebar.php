<?php
$u = usuarioLogado();
$pag = basename($_SERVER['PHP_SELF']);
$dir = basename(dirname($_SERVER['PHP_SELF']));
?>
<div class="sidebar d-flex flex-column" style="width:230px;min-height:100vh;background:#0f172a;position:fixed;top:0;left:0;bottom:0;z-index:100;overflow-y:auto">
    <div class="p-3 border-bottom border-secondary">
        <div class="d-flex align-items-center gap-2">
            <div class="bg-primary rounded p-2 text-white" style="font-size:1.2rem">📱</div>
            <div>
                <div class="fw-bold text-white" style="font-size:.9rem">ConectaFácil</div>
                <div class="text-secondary" style="font-size:.65rem">Locações Tecnológicas</div>
            </div>
        </div>
    </div>

    <nav class="flex-grow-1 p-2 pt-3">
        <div class="text-uppercase text-secondary mb-1 px-2" style="font-size:.6rem;letter-spacing:.08em">Principal</div>
        <a href="/conectafacil/dashboard.php" class="nav-link d-flex align-items-center gap-2 px-2 py-2 rounded mb-1 <?= $pag==='dashboard.php'?'bg-primary text-white':'text-secondary' ?>" style="font-size:.875rem">
            📊 Dashboard
        </a>
        <a href="/conectafacil/locacoes/index.php" class="nav-link d-flex align-items-center gap-2 px-2 py-2 rounded mb-1 <?= $dir==='locacoes'&&$pag==='index.php'?'bg-primary text-white':'text-secondary' ?>" style="font-size:.875rem">
            📋 Locações
        </a>
        <a href="/conectafacil/locacoes/nova.php" class="nav-link d-flex align-items-center gap-2 px-2 py-2 rounded mb-1 <?= $pag==='nova.php'?'bg-primary text-white':'text-secondary' ?>" style="font-size:.875rem">
            ➕ Nova Locação
        </a>

        <?php if ($u && $u['perfil'] === 'admin'): ?>
        <div class="text-uppercase text-secondary mb-1 mt-3 px-2" style="font-size:.6rem;letter-spacing:.08em">Administração</div>
        <a href="/conectafacil/admin/dispositivos.php" class="nav-link d-flex align-items-center gap-2 px-2 py-2 rounded mb-1 <?= $pag==='dispositivos.php'?'bg-primary text-white':'text-secondary' ?>" style="font-size:.875rem">
            📱 Dispositivos
        </a>
        <a href="/conectafacil/admin/clientes.php" class="nav-link d-flex align-items-center gap-2 px-2 py-2 rounded mb-1 <?= $pag==='clientes.php'?'bg-primary text-white':'text-secondary' ?>" style="font-size:.875rem">
            👥 Clientes
        </a>
        <a href="/conectafacil/admin/usuarios.php" class="nav-link d-flex align-items-center gap-2 px-2 py-2 rounded mb-1 <?= $pag==='usuarios.php'?'bg-primary text-white':'text-secondary' ?>" style="font-size:.875rem">
            🛡️ Usuários
        </a>
        <?php endif; ?>
    </nav>

    <div class="p-3 border-top border-secondary d-flex align-items-center gap-2">
        <div class="flex-grow-1" style="min-width:0">
            <div class="text-white fw-semibold" style="font-size:.8rem;white-space:nowrap;overflow:hidden;text-overflow:ellipsis"><?= h($u['nome'] ?? '') ?></div>
            <div class="badge <?= $u['perfil']==='admin'?'bg-primary':'bg-success' ?>" style="font-size:.65rem"><?= $u['perfil']==='admin'?'Administrador':'Operador' ?></div>
        </div>
        <a href="/conectafacil/logout.php" class="text-secondary" title="Sair" style="font-size:1.1rem;text-decoration:none">🚪</a>
    </div>
</div>
<div style="margin-left:230px" class="flex-grow-1">
