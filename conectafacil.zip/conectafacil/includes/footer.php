</main>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
// Auto-dismiss alerts
document.querySelectorAll('.alert').forEach(a => setTimeout(() => {
    a.style.transition='opacity .5s'; a.style.opacity='0';
    setTimeout(()=>a.remove(),500);
}, 5000));

// Confirm delete
function confirmDel(msg) { return confirm(msg || 'Tem certeza que deseja excluir? Esta ação não pode ser desfeita.'); }

// CPF mask
document.querySelectorAll('input[name=cpf]').forEach(el => el.addEventListener('input', function(){
    let v=this.value.replace(/\D/g,'').slice(0,11);
    v=v.replace(/(\d{3})(\d)/,'$1.$2').replace(/(\d{3})(\d)/,'$1.$2').replace(/(\d{3})(\d{1,2})$/,'$1-$2');
    this.value=v;
}));

// Phone mask
document.querySelectorAll('input[name=telefone]').forEach(el => el.addEventListener('input', function(){
    let v=this.value.replace(/\D/g,'').slice(0,11);
    if(v.length<=10) v=v.replace(/(\d{2})(\d)/,'($1) $2').replace(/(\d{4})(\d)/,'$1-$2');
    else v=v.replace(/(\d{2})(\d)/,'($1) $2').replace(/(\d{5})(\d)/,'$1-$2');
    this.value=v;
}));
</script>
</body>
</html>
