<?php
require_once __DIR__ . '/../config.php';

function getDB() {
    static $pdo = null;
    if ($pdo) return $pdo;

    try {
        // Primeiro conecta sem banco para criar o banco se necessário
        $dsn = 'mysql:host=' . DB_HOST . ';charset=utf8mb4';
        $tmp = new PDO($dsn, DB_USER, DB_PASS, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
        $tmp->exec("CREATE DATABASE IF NOT EXISTS `" . DB_NAME . "` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
        $tmp = null;

        // Conecta no banco
        $pdo = new PDO(
            'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4',
            DB_USER, DB_PASS,
            [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC]
        );

        // Cria tabelas se não existirem (instalação automática)
        instalarBanco($pdo);

        return $pdo;
    } catch (PDOException $e) {
        die('<div style="font-family:sans-serif;padding:2rem;background:#fee2e2;border:1px solid #f87171;border-radius:8px;margin:2rem;color:#991b1b">
            <h2>❌ Erro de Conexão com o Banco de Dados</h2>
            <p>Verifique se o MySQL está rodando no XAMPP.</p>
            <p>Se sua senha do MySQL não é vazia, edite o arquivo <strong>config.php</strong> e altere <code>DB_PASS</code>.</p>
            <p><strong>Erro técnico:</strong> ' . htmlspecialchars($e->getMessage()) . '</p>
        </div>');
    }
}

function instalarBanco($pdo) {
    // CORRIGIDO: PDO não suporta múltiplos statements em exec().
    // Cada CREATE TABLE precisa ser executado separadamente.
    $pdo->exec("CREATE TABLE IF NOT EXISTS usuarios (
        id INT AUTO_INCREMENT PRIMARY KEY,
        nome VARCHAR(100) NOT NULL,
        email VARCHAR(150) UNIQUE NOT NULL,
        senha VARCHAR(255) NOT NULL,
        perfil ENUM('admin','operador') DEFAULT 'operador',
        ativo TINYINT(1) DEFAULT 1,
        criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB");

    $pdo->exec("CREATE TABLE IF NOT EXISTS dispositivos (
        id INT AUTO_INCREMENT PRIMARY KEY,
        modelo VARCHAR(100) NOT NULL,
        marca VARCHAR(100) NOT NULL,
        imei VARCHAR(20) UNIQUE,
        valor_diaria DECIMAL(10,2) NOT NULL,
        status ENUM('disponivel','alugado','manutencao') DEFAULT 'disponivel',
        descricao TEXT,
        criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        atualizado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=InnoDB");

    $pdo->exec("CREATE TABLE IF NOT EXISTS clientes (
        id INT AUTO_INCREMENT PRIMARY KEY,
        nome VARCHAR(150) NOT NULL,
        cpf VARCHAR(14) UNIQUE,
        telefone VARCHAR(20),
        email VARCHAR(150),
        endereco TEXT,
        criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB");

    $pdo->exec("CREATE TABLE IF NOT EXISTS locacoes (
        id INT AUTO_INCREMENT PRIMARY KEY,
        cliente_id INT NOT NULL,
        dispositivo_id INT NOT NULL,
        usuario_id INT NOT NULL,
        data_retirada DATE NOT NULL,
        data_prevista_devolucao DATE NOT NULL,
        data_devolucao DATE,
        status ENUM('ativa','finalizada') DEFAULT 'ativa',
        dias_locados INT,
        valor_total DECIMAL(10,2),
        multa_atraso DECIMAL(10,2) DEFAULT 0.00,
        taxa_dano DECIMAL(10,2) DEFAULT 0.00,
        houve_dano TINYINT(1) DEFAULT 0,
        descricao_dano TEXT,
        valor_final DECIMAL(10,2),
        observacoes TEXT,
        criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (cliente_id) REFERENCES clientes(id),
        FOREIGN KEY (dispositivo_id) REFERENCES dispositivos(id),
        FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
    ) ENGINE=InnoDB");

    // Usuário admin padrão (senha: admin123)
    $existe = $pdo->query("SELECT COUNT(*) FROM usuarios")->fetchColumn();
    if ($existe == 0) {
        // CORRIGIDO: usar prepared statements para evitar que os hashes
        // de senha (que contêm $ e outros caracteres especiais) quebrem o SQL.
        $stUser = $pdo->prepare(
            "INSERT INTO usuarios (nome, email, senha, perfil) VALUES (?, ?, ?, ?)"
        );
        $stUser->execute(['Administrador', 'admin@conectafacil.com',
                          password_hash('admin123', PASSWORD_DEFAULT), 'admin']);
        $stUser->execute(['Operador', 'operador@conectafacil.com',
                          password_hash('oper123',  PASSWORD_DEFAULT), 'operador']);

        $pdo->exec("INSERT INTO dispositivos (modelo, marca, valor_diaria, status, descricao) VALUES
            ('iPhone 13',     'Apple',    45.00, 'disponivel', 'iPhone 13 128GB, excelente estado'),
            ('Galaxy S23',    'Samsung',  40.00, 'disponivel', 'Samsung Galaxy S23 256GB'),
            ('Moto G84',      'Motorola', 25.00, 'disponivel', 'Motorola Moto G84 256GB'),
            ('iPad Air 5',    'Apple',    60.00, 'disponivel', 'iPad Air 5ª geração 64GB Wi-Fi'),
            ('Galaxy Tab S8', 'Samsung',  55.00, 'disponivel', 'Samsung Galaxy Tab S8 256GB'),
            ('Redmi Note 12', 'Xiaomi',   20.00, 'disponivel', 'Xiaomi Redmi Note 12 128GB'),
            ('iPhone 14 Pro', 'Apple',    65.00, 'disponivel', 'iPhone 14 Pro 256GB'),
            ('Galaxy A54',    'Samsung',  30.00, 'disponivel', 'Samsung Galaxy A54 128GB')");

        $pdo->exec("INSERT INTO clientes (nome, cpf, telefone, email) VALUES
            ('João Silva',     '123.456.789-00', '(11) 99999-1111', 'joao@email.com'),
            ('Maria Oliveira', '987.654.321-00', '(11) 98888-2222', 'maria@email.com'),
            ('Carlos Santos',  '456.789.123-00', '(21) 97777-3333', 'carlos@email.com')");
    }
}
