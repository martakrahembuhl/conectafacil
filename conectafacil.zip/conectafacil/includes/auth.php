<?php
function iniciarSessao() {
    if (session_status() === PHP_SESSION_NONE) session_start();
}

function usuarioLogado() {
    iniciarSessao();
    return isset($_SESSION['usuario']) ? $_SESSION['usuario'] : null;
}

function exigirLogin() {
    $u = usuarioLogado();
    if (!$u) {
        setFlash('error', 'Você precisa estar logado para acessar esta página.');
        header('Location: /conectafacil/login.php');
        exit;
    }
    return $u;
}

function exigirAdmin() {
    $u = exigirLogin();
    if ($u['perfil'] !== 'admin') {
        setFlash('error', 'Acesso negado. Apenas administradores podem acessar esta área.');
        header('Location: /conectafacil/dashboard.php');
        exit;
    }
    return $u;
}

function setFlash($tipo, $msg) {
    iniciarSessao();
    $_SESSION['flash'] = ['tipo' => $tipo, 'msg' => $msg];
}

function getFlash() {
    iniciarSessao();
    if (isset($_SESSION['flash'])) {
        $f = $_SESSION['flash'];
        unset($_SESSION['flash']);
        return $f;
    }
    return null;
}

function mostraFlash() {
    $f = getFlash();
    if (!$f) return;
    $class = $f['tipo'] === 'success' ? 'alert-success' : 'alert-danger';
    $icon  = $f['tipo'] === 'success' ? '✅' : '❌';
    echo '<div class="alert ' . $class . ' alert-dismissible fade show" role="alert">'
       . $icon . ' ' . htmlspecialchars($f['msg'])
       . '<button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>';
}

function h($str) {
    return htmlspecialchars($str ?? '', ENT_QUOTES, 'UTF-8');
}

function fmt($valor) {
    return 'R$ ' . number_format((float)$valor, 2, ',', '.');
}

function fmtData($data) {
    if (!$data) return '—';
    return date('d/m/Y', strtotime($data));
}

// Detecta BASE_URL automaticamente
function baseUrl($path = '') {
    $script = dirname($_SERVER['SCRIPT_NAME']);
    // Sobe até a raiz do projeto (conectafacil)
    $parts = explode('/', trim($script, '/'));
    $root = '';
    foreach ($parts as $p) {
        if ($p === 'conectafacil') { $root = '/conectafacil'; break; }
    }
    if (!$root) $root = '/conectafacil';
    return $root . '/' . ltrim($path, '/');
}
