<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/db.php';
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= h($pageTitle ?? APP_NAME) ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background: #f1f5f9; }
        .nav-link { transition: all .15s; }
        .nav-link:not(.bg-primary):hover { background: rgba(255,255,255,.07)!important; color:#f1f5f9!important; }
        .table th { background:#f8fafc; font-size:.75rem; text-transform:uppercase; letter-spacing:.04em; color:#64748b; }
        .badge-disponivel { background:#dcfce7;color:#166534; }
        .badge-alugado { background:#ffedd5;color:#9a3412; }
        .badge-manutencao { background:#fef3c7;color:#92400e; }
        .badge-ativa { background:#dbeafe;color:#1d4ed8; }
        .badge-finalizada { background:#f1f5f9;color:#64748b;border:1px solid #e2e8f0; }
        .badge-atrasada { background:#fee2e2;color:#991b1b; }
        .stat-card { border-left:4px solid; }
        .card { border-color:#e2e8f0; }
        .alert { font-size:.9rem; }
        .form-label { font-weight:600; font-size:.85rem; }
        .page-header { margin-bottom:1.5rem; }
        .breadcrumb-link { color:#2563eb; font-size:.85rem; text-decoration:none; }
        .breadcrumb-link:hover { text-decoration:underline; }
        .table-hover tbody tr:hover { background:#f8fafc; }
        .row-warning { background:#fffbeb!important; }
        textarea { resize:vertical; }
    </style>
</head>
<body>
<div class="d-flex">
<?php include __DIR__ . '/sidebar.php'; ?>
<main class="p-4" style="min-height:100vh;width:100%">
<?php mostraFlash(); ?>
