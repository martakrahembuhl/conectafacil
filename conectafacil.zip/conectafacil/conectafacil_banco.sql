-- =====================================================
-- ConectaFácil Locações Tecnológicas
-- Banco de Dados Completo
-- Como importar: phpMyAdmin > Importar > Escolher este arquivo
-- =====================================================

CREATE DATABASE IF NOT EXISTS `conectafacil`
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE `conectafacil`;

-- =====================================================
-- TABELA: usuarios
-- =====================================================
DROP TABLE IF EXISTS `usuarios`;
CREATE TABLE `usuarios` (
  `id`         INT AUTO_INCREMENT PRIMARY KEY,
  `nome`       VARCHAR(100) NOT NULL,
  `email`      VARCHAR(150) NOT NULL UNIQUE,
  `senha`      VARCHAR(255) NOT NULL,
  `perfil`     ENUM('admin','operador') DEFAULT 'operador',
  `ativo`      TINYINT(1) DEFAULT 1,
  `criado_em`  TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- =====================================================
-- TABELA: dispositivos
-- =====================================================
DROP TABLE IF EXISTS `dispositivos`;
CREATE TABLE `dispositivos` (
  `id`            INT AUTO_INCREMENT PRIMARY KEY,
  `modelo`        VARCHAR(100) NOT NULL,
  `marca`         VARCHAR(100) NOT NULL,
  `imei`          VARCHAR(20) UNIQUE,
  `valor_diaria`  DECIMAL(10,2) NOT NULL,
  `status`        ENUM('disponivel','alugado','manutencao') DEFAULT 'disponivel',
  `descricao`     TEXT,
  `criado_em`     TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `atualizado_em` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- =====================================================
-- TABELA: clientes
-- =====================================================
DROP TABLE IF EXISTS `clientes`;
CREATE TABLE `clientes` (
  `id`         INT AUTO_INCREMENT PRIMARY KEY,
  `nome`       VARCHAR(150) NOT NULL,
  `cpf`        VARCHAR(14) UNIQUE,
  `telefone`   VARCHAR(20),
  `email`      VARCHAR(150),
  `endereco`   TEXT,
  `criado_em`  TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- =====================================================
-- TABELA: locacoes
-- =====================================================
DROP TABLE IF EXISTS `locacoes`;
CREATE TABLE `locacoes` (
  `id`                      INT AUTO_INCREMENT PRIMARY KEY,
  `cliente_id`              INT NOT NULL,
  `dispositivo_id`          INT NOT NULL,
  `usuario_id`              INT NOT NULL,
  `data_retirada`           DATE NOT NULL,
  `data_prevista_devolucao` DATE NOT NULL,
  `data_devolucao`          DATE,
  `status`                  ENUM('ativa','finalizada') DEFAULT 'ativa',
  `dias_locados`            INT,
  `valor_total`             DECIMAL(10,2),
  `multa_atraso`            DECIMAL(10,2) DEFAULT 0.00,
  `taxa_dano`               DECIMAL(10,2) DEFAULT 0.00,
  `houve_dano`              TINYINT(1) DEFAULT 0,
  `descricao_dano`          TEXT,
  `valor_final`             DECIMAL(10,2),
  `observacoes`             TEXT,
  `criado_em`               TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`cliente_id`)     REFERENCES `clientes`(`id`),
  FOREIGN KEY (`dispositivo_id`) REFERENCES `dispositivos`(`id`),
  FOREIGN KEY (`usuario_id`)     REFERENCES `usuarios`(`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- =====================================================
-- DADOS: Usuários
-- Senha do admin:    admin123
-- Senha do operador: oper123
-- =====================================================
INSERT INTO `usuarios` (`nome`, `email`, `senha`, `perfil`) VALUES
('Administrador',  'admin@conectafacil.com',    '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin'),
('Operador Padrão','operador@conectafacil.com', '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77bXm2', 'operador');

-- =====================================================
-- DADOS: Dispositivos
-- =====================================================
INSERT INTO `dispositivos` (`modelo`, `marca`, `valor_diaria`, `status`, `descricao`) VALUES
('iPhone 13',      'Apple',    45.00, 'disponivel', 'iPhone 13 128GB, excelente estado'),
('Galaxy S23',     'Samsung',  40.00, 'disponivel', 'Samsung Galaxy S23 256GB'),
('Moto G84',       'Motorola', 25.00, 'disponivel', 'Motorola Moto G84 256GB'),
('iPad Air 5',     'Apple',    60.00, 'disponivel', 'iPad Air 5ª geração 64GB Wi-Fi'),
('Galaxy Tab S8',  'Samsung',  55.00, 'disponivel', 'Samsung Galaxy Tab S8 256GB'),
('Redmi Note 12',  'Xiaomi',   20.00, 'disponivel', 'Xiaomi Redmi Note 12 128GB'),
('iPhone 14 Pro',  'Apple',    65.00, 'disponivel', 'iPhone 14 Pro 256GB'),
('Galaxy A54',     'Samsung',  30.00, 'disponivel', 'Samsung Galaxy A54 128GB');

-- =====================================================
-- DADOS: Clientes
-- =====================================================
INSERT INTO `clientes` (`nome`, `cpf`, `telefone`, `email`, `endereco`) VALUES
('João Silva',    '123.456.789-00', '(11) 99999-1111', 'joao@email.com',   'Rua das Flores, 123 - São Paulo/SP'),
('Maria Oliveira','987.654.321-00', '(11) 98888-2222', 'maria@email.com',  'Av. Paulista, 456 - São Paulo/SP'),
('Carlos Santos', '456.789.123-00', '(21) 97777-3333', 'carlos@email.com', 'Rua do Comércio, 789 - Rio de Janeiro/RJ');
